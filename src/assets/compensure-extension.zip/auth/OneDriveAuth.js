// ABOUTME: Handles Microsoft OAuth authentication for OneDrive access
// ABOUTME: Manages token storage, refresh, and authentication flow

class OneDriveAuth {
  constructor() {
    this.tokenKey = 'onedrive_tokens';
    this.userKey = 'onedrive_user';
    this.redirectUrl = chrome.identity.getRedirectURL();
    
    // Load configuration (will be available globally via config.js)
    const config = window.COMPENSURE_CONFIG?.MICROSOFT;
    if (!config) {
      throw new Error('Microsoft configuration not found. Please ensure config.js is loaded.');
    }
    
    this.clientId = config.CLIENT_ID;
    this.tenant = config.TENANT;
    this.scopes = config.SCOPES.join(' ');
    
    // Log setup information
    console.log('Chrome Extension Redirect URI for Azure setup:', this.redirectUrl);
    if (this.clientId === 'YOUR_MICROSOFT_APP_CLIENT_ID') {
      console.warn('⚠️ OneDrive authentication not configured! Please update CLIENT_ID in config.js');
    }
  }

  // Main authentication method
  async authenticate() {
    if (this.clientId === 'YOUR_MICROSOFT_APP_CLIENT_ID') {
      throw new Error('OneDrive authentication not configured. Please update CLIENT_ID in config.js');
    }
    
    const authUrl = `https://login.microsoftonline.com/${this.tenant}/oauth2/v2.0/authorize?` +
      `client_id=${this.clientId}` +
      `&response_type=token` +
      `&redirect_uri=${encodeURIComponent(this.redirectUrl)}` +
      `&scope=${encodeURIComponent(this.scopes)}` +
      `&response_mode=fragment`;

    return new Promise((resolve, reject) => {
      chrome.identity.launchWebAuthFlow(
        {
          url: authUrl,
          interactive: true
        },
        (redirectUrl) => {
          if (chrome.runtime.lastError) {
            reject(chrome.runtime.lastError);
            return;
          }
          
          try {
            // Extract tokens from redirect URL fragment
            const tokens = this.extractTokens(redirectUrl);
            this.storeTokens(tokens).then(() => {
              // Get user profile after successful auth
              this.getUserProfile(tokens.access_token).then(user => {
                resolve({ tokens, user });
              });
            });
          } catch (error) {
            reject(error);
          }
        }
      );
    });
  }

  // Extract tokens from OAuth redirect URL
  extractTokens(redirectUrl) {
    const url = new URL(redirectUrl);
    const fragment = url.hash.substring(1);
    const params = new URLSearchParams(fragment);
    
    if (params.has('error')) {
      throw new Error(`Authentication failed: ${params.get('error_description')}`);
    }
    
    const tokens = {
      access_token: params.get('access_token'),
      token_type: params.get('token_type'),
      expires_in: parseInt(params.get('expires_in')),
      scope: params.get('scope')
    };
    
    if (!tokens.access_token) {
      throw new Error('No access token received');
    }
    
    return tokens;
  }

  // Store tokens in chrome storage
  async storeTokens(tokens) {
    tokens.expires_at = new Date(Date.now() + tokens.expires_in * 1000).toISOString();
    await chrome.storage.local.set({ [this.tokenKey]: tokens });
  }

  // Get user profile from Microsoft Graph
  async getUserProfile(accessToken) {
    const response = await fetch('https://graph.microsoft.com/v1.0/me', {
      headers: {
        'Authorization': `Bearer ${accessToken}`
      }
    });
    
    if (!response.ok) {
      throw new Error('Failed to get user profile');
    }
    
    const user = await response.json();
    await chrome.storage.local.set({ [this.userKey]: user });
    return user;
  }

  // Get valid access token (refresh if needed)
  async getAccessToken() {
    const data = await chrome.storage.local.get(this.tokenKey);
    const tokens = data[this.tokenKey];
    
    if (!tokens) {
      return null;
    }
    
    // Check if token expired
    const expiresAt = new Date(tokens.expires_at);
    if (expiresAt <= new Date()) {
      // For implicit flow, we need to re-authenticate
      // (Refresh tokens require a different OAuth flow with client secret)
      return null;
    }
    
    return tokens.access_token;
  }

  // Check if user is authenticated
  async isAuthenticated() {
    const token = await this.getAccessToken();
    return token !== null;
  }

  // Get stored user info
  async getUser() {
    const data = await chrome.storage.local.get(this.userKey);
    return data[this.userKey] || null;
  }

  // Sign out
  async signOut() {
    await chrome.storage.local.remove([this.tokenKey, this.userKey, 'onedrive_sync_folder']);
    // Also clear the app state to return to login
    await chrome.storage.local.set({
      appState: {
        stage: 'login',
        timestamp: Date.now()
      }
    });
  }

  // Clear auth tokens (for re-authentication)
  async clearTokens() {
    await chrome.storage.local.remove([this.tokenKey]);
  }
}

// Export for use in extension
if (typeof module !== 'undefined' && module.exports) {
  module.exports = OneDriveAuth;
}