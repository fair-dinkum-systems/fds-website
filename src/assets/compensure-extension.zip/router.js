// ABOUTME: Routes to the correct screen based on persisted state and authentication
// ABOUTME: Manages navigation between login, initialize, and chat stages

(async function() {
    // Check if user has valid OneDrive authentication
    async function checkAuthentication() {
        try {
            const tokens = await chrome.storage.local.get('onedrive_tokens');
            if (!tokens.onedrive_tokens) {
                return false;
            }
            
            // Check if token is expired
            const expiresAt = new Date(tokens.onedrive_tokens.expires_at);
            return expiresAt > new Date();
        } catch (error) {
            console.error('Error checking authentication:', error);
            return false;
        }
    }
    
    // Check if user has selected a folder
    async function checkFolderSelection() {
        try {
            const folder = await chrome.storage.local.get('onedrive_sync_folder');
            return !!folder.onedrive_sync_folder;
        } catch (error) {
            console.error('Error checking folder selection:', error);
            return false;
        }
    }
    
    // Load the current state and redirect to appropriate screen
    async function loadScreen() {
        try {
            const result = await chrome.storage.local.get('appState');
            const stage = result.appState?.stage || 'login';

            // Check authentication status - TEMPORARILY DISABLED FOR TESTING
            const isAuthenticated = await checkAuthentication();
            const hasFolderSelected = await checkFolderSelection();
            
            // Override stage based on authentication state
            let targetStage = stage;
            
            // TEMPORARILY BYPASS AUTHENTICATION FOR TESTING
            // Always allow access to chat screen
            if (!isAuthenticated) {
                // Not authenticated, force login
                targetStage = 'login';
                
                // Update state to reflect this
                await chrome.storage.local.set({
                    appState: {
                        stage: 'login',
                        timestamp: Date.now()
                    }
                });
            } else if (isAuthenticated && !hasFolderSelected && stage === 'chat') {
                // Authenticated but no folder selected, can't go to chat
                targetStage = 'initialize';
                
                await chrome.storage.local.set({
                    appState: {
                        stage: 'initialize',
                        timestamp: Date.now()
                    }
                });
            }
            
            // Redirect to the appropriate screen
            switch(targetStage) {
                case 'login':
                    window.location.replace('login.html');
                    break;
                case 'initialize':
                    window.location.replace('initialize.html');
                    break;
                case 'chat':
                    window.location.replace('sidepanel.html');
                    break;
                default:
                    throw new Error(`Unknown app stage: ${targetStage}`);
            }
        } catch (error) {
            console.error('Error loading app state:', error);
            // Default to chat on error
            window.location.replace('sidepanel.html');
        }
    }
    
    // Load screen immediately
    loadScreen();
})();