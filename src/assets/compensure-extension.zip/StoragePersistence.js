// ABOUTME: Chrome storage persistence layer for extension conversation state
// ABOUTME: Handles conversation ID, worker ID, and worker URL with debounced writes

class StoragePersistence {
    constructor() {
        this.saveTimer = null;
        this.SAVE_DELAY = 1000; // 1 second debounce
        this.STORAGE_KEY = 'currentConversationId';
        this.WORKER_DATA_KEY = 'currentWorkerData';
    }

    // Debounced save - batches rapid changes
    scheduleSave(conversationId) {
        clearTimeout(this.saveTimer);
        this.saveTimer = setTimeout(() => {
            const saveData = {};
            saveData[this.STORAGE_KEY] = conversationId;
            chrome.storage.local.set(saveData, () => {
                if (chrome.runtime.lastError) {
                    console.error('Failed to save conversation ID:', chrome.runtime.lastError);
                } else {
                    console.log(`Saved conversation ID to storage: ${conversationId}`);
                }
            });
        }, this.SAVE_DELAY);
    }

    // Immediate save for critical changes
    saveImmediately(conversationId) {
        clearTimeout(this.saveTimer);
        const saveData = {};
        saveData[this.STORAGE_KEY] = conversationId;
        chrome.storage.local.set(saveData, () => {
            if (chrome.runtime.lastError) {
                console.error('Failed to immediately save conversation ID:', chrome.runtime.lastError);
            } else {
                console.log(`Immediately saved conversation ID to storage: ${conversationId}`);
            }
        });
    }

    // Load conversation ID from storage
    async loadConversationId() {
        return new Promise((resolve) => {
            chrome.storage.local.get([this.STORAGE_KEY], (result) => {
                if (chrome.runtime.lastError) {
                    console.error('Failed to load conversation ID:', chrome.runtime.lastError);
                    resolve(null);
                } else {
                    resolve(result[this.STORAGE_KEY] || null);
                }
            });
        });
    }

    // Save conversation ID (with optional immediate save)
    saveConversationId(conversationId, immediate = false) {
        if (immediate) {
            this.saveImmediately(conversationId);
        } else {
            this.scheduleSave(conversationId);
        }
    }

    // Load worker data from storage
    async loadWorkerData() {
        return new Promise((resolve) => {
            chrome.storage.local.get([this.WORKER_DATA_KEY], (result) => {
                if (chrome.runtime.lastError) {
                    console.error('Failed to load worker data:', chrome.runtime.lastError);
                    resolve(null);
                } else {
                    resolve(result[this.WORKER_DATA_KEY] || null);
                }
            });
        });
    }

    // Save worker data (worker ID, URL, and session token)
    saveWorkerData(workerId, workerUrl, workerToken = null, immediate = false) {
        const workerData = {
            workerId: workerId,
            workerUrl: workerUrl,
            workerToken: workerToken,
            timestamp: Date.now()
        };
        
        if (immediate) {
            this.saveWorkerDataImmediately(workerData);
        } else {
            this.scheduleWorkerSave(workerData);
        }
    }

    // Debounced worker data save
    scheduleWorkerSave(workerData) {
        clearTimeout(this.saveTimer);
        this.saveTimer = setTimeout(() => {
            const saveData = {};
            saveData[this.WORKER_DATA_KEY] = workerData;
            chrome.storage.local.set(saveData, () => {
                if (chrome.runtime.lastError) {
                    console.error('Failed to save worker data:', chrome.runtime.lastError);
                } else {
                    console.log(`Saved worker data to storage: ${workerData.workerId} at ${workerData.workerUrl}`);
                }
            });
        }, this.SAVE_DELAY);
    }

    // Immediate worker data save
    saveWorkerDataImmediately(workerData) {
        clearTimeout(this.saveTimer);
        const saveData = {};
        saveData[this.WORKER_DATA_KEY] = workerData;
        chrome.storage.local.set(saveData, () => {
            if (chrome.runtime.lastError) {
                console.error('Failed to immediately save worker data:', chrome.runtime.lastError);
            } else {
                console.log(`Immediately saved worker data to storage: ${workerData.workerId} at ${workerData.workerUrl}`);
            }
        });
    }

    // Clear conversation ID
    clearConversationId() {
        chrome.storage.local.remove([this.STORAGE_KEY], () => {
            if (chrome.runtime.lastError) {
                console.error('Failed to clear conversation ID:', chrome.runtime.lastError);
            } else {
                console.log('Conversation ID cleared from storage');
            }
        });
    }
}

// Export for both Node.js (testing) and browser
if (typeof module !== 'undefined' && module.exports) {
    module.exports = StoragePersistence;
} else {
    // Make available globally in browser
    window.StoragePersistence = StoragePersistence;
}