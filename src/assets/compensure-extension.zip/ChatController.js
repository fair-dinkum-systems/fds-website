// ABOUTME: Chat controller class handling DOM manipulation, polling, and user interactions
// ABOUTME: Determines mode and turn state from conversation data and coordinates with chat UI

// Import classes for Node.js environment (browser gets them from window)
if (typeof module !== 'undefined' && typeof require !== 'undefined') {
    const Conversation = require('./Conversation');
    const Message = require('./Message');
}

class ChatController {
    constructor(storagePersistence = null, workerManager = null) {
        this.storage = storagePersistence;
        this.workerManager = workerManager;
        this.chatWindow = null;
        this.taskStatusInterval = null;
        this.conversationPollingInterval = null;
        this.conversation = null; // Will be initialized from server or created new
        this.lastStoredConversationId = null; // Track what's currently stored
    }

    // Check if conversation is complete based on last message
    waitingForUser() {
        if (!this.conversation || !this.conversation.messages || this.conversation.messages.length === 0) {
            return true; // No messages means no task in progress
        }
        
        const lastMessage = this.conversation.messages[this.conversation.messages.length - 1];
        return lastMessage.type === 'system_message' && 
               lastMessage.content === 'Message processed successfully';
    }
    
    // Mode and turn detection methods (replacing ChatModeManager)
    getCurrentMode() {
        return this.waitingForUser() ? 'waiting' : 'processing';
    }

    getCurrentTurn() {
        if (!this.conversation || !this.conversation.messages || this.conversation.messages.length === 0) {
            return 'user_turn'; // No messages yet, user's turn
        }

        if (this.getCurrentMode() == "processing") {
            return 'assistant_turn';
        }
        
        const lastMessage = this.conversation.messages[this.conversation.messages.length - 1];
        return lastMessage.type === 'user_message' ? 'assistant_turn' : 'user_turn';
    }

    async init() {
        await this.initializeFromStorage();
        this.setupEventListeners();
    }

    // Initialize from Chrome storage and backend
    async initializeFromStorage() {
        if (!this.storage) {
            // No storage available, use default initialization
            this.initializeConversation();
            return;
        }

        // Load conversation ID from storage
        const conversationId = await this.storage.loadConversationId();
        this.lastStoredConversationId = conversationId; // Track what's currently stored
        
        if (conversationId) {
            console.log('Found stored conversation ID:', conversationId);
            
            try {
                // Try to load conversation from backend
                const result = await api.getConversation(conversationId);
                
                if (result.success && result.data) {
                    // Initialize conversation from backend data
                    this.conversation = Conversation.fromJSON(result.data);
                    console.log('Conversation loaded from backend:', this.conversation.id);
                    
                    // Check if there are any active tasks and start polling if needed
                    const activeTask = this.conversation.getCurrentTask();
                    if (this.getCurrentMode() == 'processing') {
                        console.log('Found active task on load, starting polling for task:', activeTask.id);
                        this.startTaskStatusPolling(activeTask.id);

                    }
                } else if (result.reason === 'no_worker_url') {
                    // Worker URL not available yet, defer conversation loading
                    console.log('Worker URL not available yet, deferring conversation load');
                    return; // Don't initialize conversation yet, wait for worker URL
                } else {
                    console.log('Conversation not found on backend, starting fresh');
                    this.initializeConversation();
                }
            } catch (error) {
                console.error('Failed to load conversation from backend:', error);
                this.initializeConversation();
            }
        } else {
            console.log('No stored conversation ID found, starting fresh');
            this.initializeConversation();
        }
    }

    // Retry loading conversation after worker URL becomes available
    async retryConversationLoad() {
        if (!this.storage) {
            return;
        }

        // Only retry if we don't already have a conversation loaded
        if (this.conversation) {
            return;
        }

        const conversationId = await this.storage.loadConversationId();
        if (conversationId) {
            console.log('Retrying conversation load with worker URL now available:', conversationId);
            
            try {
                const result = await api.getConversation(conversationId);
                
                if (result.success && result.data) {
                    // Initialize conversation from backend data
                    this.conversation = Conversation.fromJSON(result.data);
                    console.log('Conversation loaded from backend on retry:', this.conversation.id);
                    
                    // Display stored messages
                    this.displayStoredMessages();
                    
                    // Check if there are any active tasks and start polling if needed
                    const activeTask = this.conversation.getCurrentTask();
                    if (this.getCurrentMode() == 'processing') {
                        console.log('Found active task on retry load, starting polling for task:', activeTask.id);
                        this.startTaskStatusPolling(activeTask.id);
                    }
                } else {
                    console.log('Conversation not found on backend during retry, starting fresh');
                    this.initializeConversation();
                }
            } catch (error) {
                console.error('Failed to load conversation from backend on retry:', error);
                this.initializeConversation();
            }
        }
    }

    // Display stored messages in the chat UI
    displayStoredMessages() {
        if (!this.chatWindow || !this.conversation || !this.conversation.messages) {
            return;
        }

        // Display all messages from the conversation (both user and assistant)
        for (const message of this.conversation.messages) {
            if (message.type === 'user_message') {
                // User messages: wrap in bubble-button bubble-pick div and use reply reply-freeform class
                const userContent = '<div class="bubble-button bubble-pick">' + message.content + '</div>';
                this.chatWindow.addStoredBubble(userContent, "reply reply-freeform");
            } else if (message.type === 'assistant_message') {
                // Assistant messages: use addStoredBubble with no reply class (empty string)
                this.chatWindow.addStoredBubble(message.content, "instant");
            }
        }
    }

    initializeConversation() {
        // Initialize a new conversation object with a generated UUID
        const now = new Date().toISOString();
        const conversationId = this.generateUUID();
        this.conversation = new Conversation(
            conversationId,
            now,
            now,
            'active',
            [],
            []
        );
        // Track whether this conversation has been sent to the backend
        this.conversation.sentToBackend = false;
        
        // Save conversation ID to storage
        this.saveConversationIdToStorage();
    }

    // Save conversation ID to storage (only when it changes)
    saveConversationIdToStorage(immediate = false) {
        if (this.storage && this.conversation && this.conversation.id !== this.lastStoredConversationId) {
            this.storage.saveConversationId(this.conversation.id, immediate);
            this.lastStoredConversationId = this.conversation.id;
        }
    }

    generateUUID() {
        // Simple UUID v4 generator for client-side use
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
            const r = Math.random() * 16 | 0;
            const v = c === 'x' ? r : (r & 0x3 | 0x8);
            return v.toString(16);
        });
    }

    setupEventListeners() {
        const endTaskBtn = document.getElementById('end-task-btn');

        if (endTaskBtn) {
            endTaskBtn.addEventListener('click', () => {
                this.endTask();
            });
        }
    }

    updateUI() {
        // Update DOM based on current state
        if (typeof document !== 'undefined') {
            document.body.setAttribute('data-mode', this.getCurrentMode());
            document.body.setAttribute('data-turn', this.getCurrentTurn());
        }

        // Update chat interface if needed
        this.updateChatInterface();
    }

    updateChatInterface() {
        // This method can be used for any chat interface updates if needed
        // Note: Task completion messages are handled by endTask() method
        
        // Handle loading spinner visibility
        const spinner = document.querySelector('.loading-spinner');
        if (spinner) {
            const currentTurn = this.getCurrentTurn();
            if (currentTurn === 'assistant_turn') {
                spinner.classList.remove('hidden');
            } else {
                spinner.classList.add('hidden');
            }
        }
        
        // Handle textarea input restrictions
        const textarea = document.querySelector('.input-wrap textarea');
        if (textarea) {
            // Disable input during assistant_turn or processing mode
            const shouldDisable = this.getCurrentTurn() === 'assistant_turn' || 
                                  this.getCurrentMode() === 'processing';
            textarea.disabled = shouldDisable;
        }
    }

    async clearConversation() {
        // Stop any polling first
        this.stopConversationPolling();
        this.stopTaskStatusPolling();
        
        try {
            // Only call the backend if the conversation has been sent to the backend
            const conversationId = this.conversation?.id;
            const hasValidId = conversationId && conversationId !== '';
            const sentToBackend = this.conversation?.sentToBackend;
            
            if (hasValidId && sentToBackend) {
                console.log(`[CLEAR] Calling backend to end conversation (ID: ${conversationId})...`);
                await api.endConversation(conversationId);
                console.log(`[CLEAR] Successfully called backend to end conversation`);
            } else {
                console.log(`[CLEAR] Conversation not sent to backend yet, skipping API call (ID: ${conversationId || 'none'}, sent: ${sentToBackend})`);
            }
        } catch (error) {
            console.error('[CLEAR] Failed to end conversation on backend:', error);
            console.error('[CLEAR] Continuing with local cleanup despite backend error');
            // Continue with UI cleanup even if server call fails
        }
        
        // Clear local conversation data (check if conversation exists first)
        console.log('[CLEAR] Clearing local conversation state...');
        if (this.conversation && this.conversation.clear) {
            this.conversation.clear();
            // Update storage with new conversation ID
            this.saveConversationIdToStorage(true);
        } else {
            console.log('[CLEAR] No conversation object to clear or clear method not available');
            // Clear conversation ID from storage
            if (this.storage) {
                this.storage.clearConversationId();
                this.lastStoredConversationId = null;
            }
        }
        
        if (this.chatWindow) {
            // Clear only bubble elements, preserve bubbleTyping element
            const bubbleWrap = document.querySelector('.bubble-wrap');
            if (bubbleWrap) {
                // Remove all bubble elements but keep the bubbleTyping element
                const bubbles = bubbleWrap.querySelectorAll('.bubble:not(.bubble-typing)');
                bubbles.forEach(bubble => bubble.remove());
                console.log(`[CLEAR] Removed ${bubbles.length} message bubbles from UI`);
            }
            
            // Restart chat without any automatic message
            // Just enable input for clean slate
        }
        
        console.log('[CLEAR] Conversation cleared successfully - ready for new conversation');
    }

    setChatWindow(chatWindow) {
        this.chatWindow = chatWindow;
        // Display any stored messages that were loaded during initialization
        if (this.conversation && this.conversation.messages) {
            requestAnimationFrame(() => {
                this.displayStoredMessages();
                this.updateUI();
            });
        } else {
            this.updateUI();
        }
    }

    // Method to start a task - handles both state and UI
    startTask(taskId) {
        // Processing mode is now determined by conversation not being complete
        this.updateUI();
        this.startTaskStatusPolling(taskId);
    }

    endTask() {
        // Waiting mode is now determined by conversation being complete
        this.stopTaskStatusPolling();
        this.updateUI();
        
        if (this.chatWindow) {
            this.chatWindow.reply({
                says: ["Task completed! Back to waiting mode."],
                input: true
            });
        }
    }

    async handleUserInput(userInput) {
        try {
            // Check if worker is ready before processing input
            if (!this.workerManager || !this.workerManager.isWorkerReady()) {
                const errorMessage = new Message(
                    'msg-' + Date.now(),
                    'assistant_message',
                    'Worker is not ready yet. Please wait for worker initialization to complete before sending messages.',
                    new Date().toISOString()
                );
                this.conversation.addMessage(errorMessage);
                this.updateUI();
                
                // Show error in chat window
                if (this.chatWindow) {
                    this.chatWindow.reply({
                        says: ['Worker is not ready yet. Please wait for worker initialization to complete before sending messages.'],
                        input: true
                    });
                }
                return;
            }

            // Add user message to conversation
            const userMessage = new Message(
                'msg-' + Date.now(),
                'user_message',
                userInput,
                new Date().toISOString()
            );
            this.conversation.addMessage(userMessage);
            
            // UI will update based on last message being user_message (assistant's turn)
            this.updateUI();

            // Submit task to server - always pass conversation ID (required by new API)
            const conversationId = this.conversation.id;
            const result = await api.addMessage(userInput, conversationId);
            
            if (result.success) {
                const data = result.data;
                
                // Mark conversation as sent to backend
                this.conversation.sentToBackend = true;
                
                // Update conversation ID if server provided one
                if (data.conversation_id && data.conversation_id !== this.conversation.id) {
                    this.conversation.id = data.conversation_id;
                    // Save updated conversation ID to storage (will only save if it changed)
                    this.saveConversationIdToStorage();
                }
                
                // Server is processing the message in background
                // Start polling for conversation updates
                this.chatWindow.reply({
                    says: ['Processing...'],
                    input: false
                });
                
                // Start polling for conversation updates
                this.startConversationPolling(this.conversation.id);
            } else {
                // Handle error - add error message so user can respond
                const errorMessage = new Message(
                    'msg-' + Date.now(),
                    'assistant_message',
                    result.message || 'Unknown error occurred',
                    new Date().toISOString()
                );
                this.conversation.addMessage(errorMessage);
                this.updateUI();
                this.chatWindow.reply({
                    says: [`Error: ${result.message || 'Unknown error occurred'}`],
                    input: true
                });
            }
        } catch (error) {
            console.error('Error handling user input:', error);
            // Error occurred - add error message so user can respond
            const errorMessage = new Message(
                'msg-' + Date.now(),
                'assistant_message',
                `Error: Could not connect to worker. Please ensure worker is initialized and active.`,
                new Date().toISOString()
            );
            this.conversation.addMessage(errorMessage);
            this.updateUI();
            this.chatWindow.reply({
                says: [`Error: Could not connect to worker. Please ensure worker is initialized and active.`],
                input: true
            });
        }
    }

    startTaskStatusPolling(taskId) {
        // Safety check: don't start polling if no task ID or already polling
        if (!taskId || this.taskStatusInterval) {
            console.log('Skipping polling start - no task ID or already polling');
            return;
        }
        
        console.log(`Starting task status polling for task ${taskId} in conversation ${this.conversation.id}`);
        
        // Immediately poll once before starting interval
        this.pollTaskStatus(this.conversation.id, taskId);
        
        // Set up periodic polling (only runs while task is executing)
        this.taskStatusInterval = setInterval(async () => {
            // Only poll if conversation is not complete
            if (!this.waitingForUser()) {
                await this.pollTaskStatus(this.conversation.id, taskId);
            } else {
                // Task is no longer executing, stop polling
                this.stopTaskStatusPolling();
            }
        }, 2000); // Poll every 2 seconds
    }
    
    async pollTaskStatus(conversationId, taskId) {
        if (!conversationId || !taskId || this.waitingForUser()) {
            console.log(`[POLL] Skipping poll - conversationId: ${conversationId}, taskId: ${taskId}, complete: ${this.waitingForUser()}`);
            return;
        }
        
        const currentTask = this.conversation.getTaskById(taskId);
        if (!currentTask) {
            console.log(`[POLL] Task ${taskId} not found in conversation`);
            return;
        }
        
        const currentConversationMessageCount = this.conversation.messages ? this.conversation.messages.length : 0;
        console.log(`[POLL] Polling conversation ${conversationId} for task ${taskId}, current conversation messages: ${currentConversationMessageCount}`);
        
        try {
            const conversationResult = await api.getConversation(conversationId);
            
            if (conversationResult.success) {
                const conversationData = conversationResult.data;
                
                // Find the task in the conversation data
                const taskData = conversationData.tasks?.find(t => t.id === taskId);
                if (!taskData) {
                    console.log(`[POLL] Task ${taskId} not found in conversation data`);
                    return;
                }
                console.log(`[POLL] Task status: ${taskData.status}, conversation message count: ${conversationData.messages ? conversationData.messages.length : 0}`);
                
                // Update task in conversation
                this.conversation.updateTask(taskId, {
                    status: taskData.status,
                    updated_at: taskData.updated_at || new Date().toISOString(),
                    messages: taskData.messages || [],
                    result: taskData.result || null
                });
                
                // Process any new conversation messages
                if (conversationData.messages && conversationData.messages.length > currentConversationMessageCount) {
                    // Show any new messages from the conversation
                    const newMessages = conversationData.messages.slice(currentConversationMessageCount);
                    console.log(`[POLL] Found ${newMessages.length} new conversation messages to display`);
                    
                    // Update our conversation messages
                    this.conversation.messages = conversationData.messages;
                    
                    for (const messageObj of newMessages) {
                        console.log(`[POLL] Processing conversation message:`, messageObj);
                        if (this.chatWindow) {
                            // Extract message content - conversation messages have .content field
                            const messageText = messageObj.content;
                            console.log(`[POLL] About to display message of length: ${messageText.length}`);
                            console.log(`[POLL] Message preview: ${messageText.substring(0, 100)}...`);
                            
                            try {
                                console.log(`[POLL] Calling chatWindow.reply...`);
                                this.chatWindow.reply({
                                    says: [messageText],
                                    input: false
                                });
                                console.log(`[POLL] chatWindow.reply completed successfully`);
                            } catch (error) {
                                console.error(`[POLL] Error in chatWindow.reply:`, error);
                                console.error(`[POLL] Failed message length: ${messageText.length}`);
                                console.error(`[POLL] Failed message content: ${messageText.substring(0, 200)}...`);
                            }
                        }
                    }
                    
                    console.log(`[POLL] Displayed ${newMessages.length} new conversation messages`);
                } else {
                    console.log(`[POLL] No new conversation messages to display`);
                }
                
                // Then check if task is complete and handle completion
                if (taskData.status === 'completed' || taskData.status === 'failed') {
                    console.log(`[POLL] Task ${taskData.status}, stopping execution`);
                    // UI will update based on no active tasks (chat mode)
                    this.updateUI();
                }
            } else {
                console.error('[POLL] Failed to get conversation:', conversationResult.message);
            }
        } catch (error) {
            console.error('[POLL] Error polling conversation:', error);
            // On error, tasks will appear as failed/complete, so UI will update accordingly
            this.updateUI();
        }
    }

    stopTaskStatusPolling() {
        if (this.taskStatusInterval) {
            console.log('Stopping task status polling');
            clearInterval(this.taskStatusInterval);
            this.taskStatusInterval = null;
        }
    }

    startConversationPolling(conversationId) {
        // Stop any existing polling
        this.stopConversationPolling();
        
        console.log(`Starting conversation polling for ${conversationId}`);
        
        // Immediately poll once
        this.pollConversation(conversationId);
        
        // Set up periodic polling
        this.conversationPollingInterval = setInterval(async () => {
            await this.pollConversation(conversationId);
        }, 2000); // Poll every 2 seconds
    }

    async pollConversation(conversationId) {
        if (!conversationId) {
            console.log(`[POLL] Skipping poll - no conversationId`);
            return;
        }
        
        const currentMessageCount = this.conversation.messages ? this.conversation.messages.length : 0;
        console.log(`[POLL] Polling conversation ${conversationId}, current message count: ${currentMessageCount}`);
        
        try {
            const conversationResult = await api.getConversation(conversationId);
            
            if (conversationResult.success) {
                const conversationData = conversationResult.data;
                console.log(`[POLL] Got conversation data with ${conversationData.messages ? conversationData.messages.length : 0} messages`);
                
                // Check if there are new messages
                if (conversationData.messages && conversationData.messages.length > currentMessageCount) {
                    // Show any new messages
                    const newMessages = conversationData.messages.slice(currentMessageCount);
                    console.log(`[POLL] Found ${newMessages.length} new messages to display`);
                    
                    // Update our conversation messages
                    this.conversation.messages = conversationData.messages;
                    
                    let conversationComplete = false;
                    
                    for (const messageObj of newMessages) {
                        // Check if conversation is complete using our centralized function
                        if (this.waitingForUser()) {
                            console.log(`[POLL] Got conversation completion message, will stop polling`);
                            conversationComplete = true;
                            continue;  // Don't display this system message
                        }
                        
                        // Skip other system messages and processing messages  
                        if (messageObj.type === 'system_message' || 
                            messageObj.content === 'Processing message...') {
                            continue;
                        }
                        
                        console.log(`[POLL] Processing message:`, messageObj);
                        
                        if (messageObj.type === 'assistant_message' && this.chatWindow) {
                            const messageText = messageObj.content;
                            console.log(`[POLL] Displaying assistant message: ${messageText.substring(0, 100)}...`);
                            
                            try {
                                this.chatWindow.reply({
                                    says: [messageText],
                                    input: false  // Keep input disabled while more messages may come
                                });
                            } catch (error) {
                                console.error(`[POLL] Error displaying message:`, error);
                            }
                        }
                    }
                    
                    // Only stop polling and re-enable input when conversation is complete
                    if (conversationComplete) {
                        console.log(`[POLL] Conversation complete, stopping polling and enabling input`);
                        this.stopConversationPolling();
                        this.updateUI();
                        
                        // Re-enable input for user
                        if (this.chatWindow) {
                            this.chatWindow.reply({
                                says: [],  // Empty message just to enable input
                                input: true
                            });
                        }
                    }
                }
                
                // Check conversation status
                if (conversationData.status === 'completed' || conversationData.status === 'failed') {
                    console.log(`[POLL] Conversation ${conversationData.status}, stopping polling`);
                    this.stopConversationPolling();
                    this.updateUI();
                }
            } else {
                console.error('[POLL] Failed to get conversation:', conversationResult.message);
            }
        } catch (error) {
            console.error('[POLL] Error polling conversation:', error);
            this.stopConversationPolling();
            this.updateUI();
        }
    }

    stopConversationPolling() {
        if (this.conversationPollingInterval) {
            console.log('Stopping conversation polling');
            clearInterval(this.conversationPollingInterval);
            this.conversationPollingInterval = null;
        }
    }
}

// Export for both Node.js (testing) and browser
if (typeof module !== 'undefined' && module.exports) {
    module.exports = ChatController;
} else {
    // Make available globally in browser
    window.ChatController = ChatController;
}