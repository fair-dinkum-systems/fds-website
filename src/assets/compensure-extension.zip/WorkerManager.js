// ABOUTME: Manages worker creation and lifecycle for remote CompenSure server instances
// ABOUTME: Handles communication with AWS Lambda worker manager and polls for worker readiness

class WorkerManager {
    constructor(auth) {
        this.workerId = null;
        this.workerUrl = null;
        this.workerStatus = null;
        this.workerToken = null;
        this.auth = auth;
        this.pollInterval = null;
        this.pollStartTime = null;
        this.currentLoadingWordIndex = 0;
        this.loadingWords = ['streaming', 'checking', 'confirming', 'initializing', 'connecting', 'validating', 'preparing'];
        this.claudeAuthState = null;
        this.claudeOAuthUrl = null;
        this.storage = new StoragePersistence();
        this.onWorkerReadyCallbacks = [];
        this.workerReadyNotified = false;
    }

    async initialize() {
        // Load stored worker data if available
        const workerData = await this.storage.loadWorkerData();
        if (workerData && workerData.workerId && workerData.workerUrl) {
            console.log(`Loaded stored worker: ${workerData.workerId} at ${workerData.workerUrl}`);
            this.workerId = workerData.workerId;
            this.workerUrl = workerData.workerUrl;
            this.workerToken = workerData.workerToken;
            this.workerStatus = 'verifying'; // Mark as verifying until confirmed
            
            // Check if the stored worker is still active
            try {
                await this.checkWorkerStatus();
                console.log(`Stored worker verified, status: ${this.workerStatus}`);
                
                // Check Claude auth status if worker is active
                if (this.workerStatus === 'active') {
                    await this.checkClaudeAuthStatus();
                }
            } catch (error) {
                console.error('Stored worker is no longer valid:', error);
                this.clearWorkerData();
                this.workerStatus = 'inactive';
            }
        } else {
            console.log('No stored worker data found', workerData);
        }
}

    async getWorkerManagerUrl() {
        return getWorkerManagerURL();
    }

    async getAuthHeaders() {
        const accessToken = await this.auth.getAccessToken();
        if (!accessToken) {
            throw new Error('No valid auth token available for worker creation');
        }
        return {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${accessToken}`
        };
    }

    async createWorker() {
        try {
            await this.initialize();
            
            const baseUrl = await this.getWorkerManagerUrl();
            const headers = await this.getAuthHeaders();
            
            const response = await fetch(`${baseUrl}/workers`, {
                method: 'POST',
                headers: headers
            });

            if (!response.ok) {
                const errorText = await response.text();
                let errorData;
                try {
                    errorData = JSON.parse(errorText);
                } catch (e) {
                    errorData = { error: errorText };
                }
                
                // Create a detailed error object for better error handling
                const error = new Error(errorData.error || `Failed to create worker: ${response.status}`);
                error.status = response.status;
                error.errorData = errorData;
                
                throw error;
            }

            const data = await response.json();
            this.workerId = data.worker_id;
            this.workerStatus = data.status;
            
            // Capture worker token from initial creation response
            console.log("data: ", data);
            if (data.worker_token) {
                this.workerToken = data.worker_token;
                console.log('Worker token received from creation response');
            } else {
                const workerData = await this.storage.loadWorkerData()
                console.log('worker token not in creation response, checking storage:', workerData);
               if (!workerData.workerToken) {
                   throw new Error('Loaded an existing worker but no worker token found in storage {worker init response: ' + JSON.stringify(data) + '}');
               }
                this.workerToken = workerData.workerToken;
            }
            
            // For starting workers, we don't have URL yet
            if (data.status === 'active') {
                if (!data.public_ip || !data.port) {
                    throw new Error('Incomplete worker data received for active worker, missing public_ip and port {data: ' + JSON.stringify(data) + '}');
                }
                this.workerUrl = `http://${data.public_ip}:${data.port}`;
                // Save worker data including token now that we have the URL
                this.storage.saveWorkerData(this.workerId, this.workerUrl, this.workerToken, true);
            } else {
                // For starting workers, save what we have so far (worker_id and token)
                // URL will be saved later when worker becomes active
                this.storage.saveWorkerData(this.workerId, null, this.workerToken, true);
            }

            // Start background polling for status updates
            this.startStatusPolling();

            return {
                workerId: this.workerId,
                status: this.workerStatus
            };

        } catch (error) {
            console.error('Error creating worker:', error);
            throw error;
        }
    }

    async checkWorkerStatus(workerId = this.workerId) {
        if (!workerId) {
            throw new Error('No worker ID available');
        }

        try {
            const baseUrl = await this.getWorkerManagerUrl();
            const headers = await this.getAuthHeaders();
            
            const response = await fetch(`${baseUrl}/workers/${workerId}/status`, {
                method: 'GET',
                headers: headers
            });

            if (!response.ok) {
                throw new Error(`Failed to check worker status: ${response.status} - ${await response.text()}`);
            }

            const data = await response.json();

            if (!data.status) {
                throw new Error('Incomplete worker status data received, {data: ' + JSON.stringify(data) + '}');
            }
            
            // Update internal state
            this.workerStatus = data.status;
            
            // Update worker URL if worker is active
            if (data.status === 'active' && data.public_ip && data.port) {
                const newUrl = `http://${data.public_ip}:${data.port}`;
                if (this.workerUrl !== newUrl) {
                    this.workerUrl = newUrl;
                    
                    // Save worker data to storage when URL becomes available (preserve existing token)
                    if (this.workerId) {
                        this.storage.saveWorkerData(this.workerId, this.workerUrl, this.workerToken, true);
                    }
                    // Worker is active, now check Claude auth status
                    this.checkClaudeAuthStatus().catch(error => {
                        console.error('Failed to check Claude auth status:', error);
                    });
                    
                    // Notify callbacks if worker is ready
                    if (this.isWorkerReady()) {
                        this.notifyWorkerReady();
                    }
                }
            }

            return data;
        } catch (error) {
            console.error('Error checking worker status:', error);
            throw error;
        }
    }

    startStatusPolling() {
        if (this.pollInterval) {
            clearInterval(this.pollInterval);
        }

        this.pollInterval = setInterval(async () => {
            try {
                await this.checkWorkerStatus();
            } catch (error) {
                console.error('Error during status polling:', error);
                // Continue polling even on error
            }
        }, 5000); // Poll every 5 seconds
    }

    stopStatusPolling() {
        if (this.pollInterval) {
            clearInterval(this.pollInterval);
            this.pollInterval = null;
        }
    }

    // Get current loading status for UI display
    getLoadingStatus() {
        if (!this.pollStartTime) {
            this.pollStartTime = Date.now();
        }
        
        const elapsed = (Date.now() - this.pollStartTime) / 1000;
        const timeSinceLastPoll = elapsed.toFixed(3);
        const loadingWord = this.loadingWords[this.currentLoadingWordIndex];
        
        return {
            status: this.workerStatus,
            timeSinceLastPoll: timeSinceLastPoll,
            loadingWord: loadingWord,
            message: `${loadingWord} ${timeSinceLastPoll}s`
        };
    }

    // Advance to next loading word (called when status changes)
    nextLoadingWord() {
        this.currentLoadingWordIndex = (this.currentLoadingWordIndex + 1) % this.loadingWords.length;
        this.pollStartTime = Date.now(); // Reset timer
    }

    getWorkerUrl() {
        return this.workerUrl;
    }

    getWorkerToken() {
        return this.workerToken;
    }

    getWorkerStatus() {
        return {
            workerId: this.workerId,
            status: this.workerStatus,
            url: this.workerUrl,
            workerToken: this.workerToken
        };
    }

    isWorkerReady() {
        return this.workerStatus === 'active' && this.workerUrl && this.claudeAuthState === 'AUTHENTICATED';
    }

    async checkClaudeAuthStatus() {
        if (!this.workerUrl) {
            throw new Error('No worker URL available for Claude auth check');
        }

        try {
            const headers = { 'Content-Type': 'application/json' };
            if (this.workerToken) {
                headers['Authorization'] = `Bearer ${this.workerToken}`;
            }
            
            const response = await fetch(`${this.workerUrl}/auth/status`, {
                method: 'GET',
                headers: headers
            });

            if (!response.ok) {
                throw new Error(`Failed to check Claude auth status: ${response.status}`);
            }

            const data = await response.json();
            const newState = data.state;
            
            this.claudeAuthState = newState;

            // Notify callbacks if worker just became ready
            if (this.isWorkerReady()) {
                this.notifyWorkerReady();
            }

            return newState;
        } catch (error) {
            console.error('Error checking Claude auth status:', error);
            throw error;
        }
    }

    async getClaudeLoginUrl() {
        if (!this.workerUrl) {
            throw new Error('No worker URL available for Claude auth');
        }

        try {
            const headers = { 'Content-Type': 'application/json' };
            if (this.workerToken) {
                headers['Authorization'] = `Bearer ${this.workerToken}`;
            }
            
            const response = await fetch(`${this.workerUrl}/auth/login-url`, {
                method: 'GET',
                headers: headers
            });

            if (!response.ok) {
                throw new Error(`Failed to get Claude login URL: ${response.status}`);
            }

            const data = await response.json();
            if (data.success && data.login_url) {
                this.claudeOAuthUrl = data.login_url;
                this.claudeAuthState = data.state;
                return data.login_url;
            } else {
                throw new Error(data.error || 'Failed to get login URL');
            }
        } catch (error) {
            console.error('Error getting Claude login URL:', error);
            throw error;
        }
    }

    async authenticateClaudeWithCode(code) {
        if (!this.workerUrl) {
            throw new Error('No worker URL available for Claude auth');
        }

        try {
            const headers = { 'Content-Type': 'application/json' };
            if (this.workerToken) {
                headers['Authorization'] = `Bearer ${this.workerToken}`;
            }
            
            const response = await fetch(`${this.workerUrl}/auth/authenticate`, {
                method: 'POST',
                headers: headers,
                body: JSON.stringify({ code: code })
            });

            if (!response.ok) {
                throw new Error(`Failed to authenticate with Claude: ${response.status}`);
            }

            const data = await response.json();
            if (data.success) {
                this.claudeAuthState = data.state;
                return true;
            } else {
                throw new Error(data.error || 'Authentication failed');
            }
        } catch (error) {
            console.error('Error authenticating with Claude:', error);
            throw error;
        }
    }


    getClaudeAuthState() {
        return this.claudeAuthState;
    }

    // Method to manually set worker data (useful for connecting to existing workers)
    setWorkerData(workerId, workerUrl, workerToken = null) {
        this.workerId = workerId;
        this.workerUrl = workerUrl;
        this.workerToken = workerToken;
        this.workerStatus = 'active';
        
        this.storage.saveWorkerData(workerId, workerUrl, workerToken, true);
        
        console.log(`Worker data set: ${workerId} at ${workerUrl}`);
        
        // Check Claude auth status
        this.checkClaudeAuthStatus().catch(error => {
            console.error('Failed to check Claude auth status:', error);
        });
    }

    clearWorkerData() {
        this.workerId = null;
        this.workerUrl = null;
        this.workerToken = null;
        this.workerStatus = null;
        this.claudeAuthState = null;
        this.claudeOAuthUrl = null;
        this.workerReadyNotified = false;
    }

    onWorkerReady(callback) {
        this.onWorkerReadyCallbacks.push(callback);
    }

    notifyWorkerReady() {
        // Prevent duplicate notifications
        if (this.workerReadyNotified) {
            return;
        }
        
        this.workerReadyNotified = true;
        this.onWorkerReadyCallbacks.forEach(callback => {
            try {
                callback(this);
            } catch (error) {
                console.error('Error in worker ready callback:', error);
            }
        });
    }

    reset() {
        this.stopStatusPolling();
        this.clearWorkerData();
        this.onWorkerReadyCallbacks = [];
        this.workerReadyNotified = false;
        this.currentLoadingWordIndex = 0;
    }
}

// Export for testing
if (typeof module !== 'undefined' && module.exports) {
    module.exports = WorkerManager;
}