# OneDrive Authentication Setup Guide

This guide will walk you through setting up Microsoft Azure OAuth authentication so that **any user** can connect their OneDrive account to your Chrome extension.

## Prerequisites

- Microsoft account (personal or work/school)
- Chrome extension loaded in developer mode
- Internet connection

## Step 1: Create Azure App Registration

1. **Go to Azure Portal**
   - Visit: https://portal.azure.com
   - Sign in with any Microsoft account

2. **Navigate to App Registrations**
   - Search for "App registrations" in the top search bar
   - Click on "App registrations" service

3. **Create New Registration**
   - Click "New registration"
   - **Name**: `CompenSure OneDrive Extension` (or your preferred name)
   - **Supported account types**: Select **"Accounts in any organizational directory (Any Microsoft Entra ID tenant - Multitenant) and personal Microsoft accounts (e.g. Skype, Xbox)"**
     - ⚠️ **CRITICAL**: This setting allows ANY Microsoft account holder to use your extension
   - **Redirect URI**: Leave blank for now
   - Click "Register"

4. **Copy your Client ID**
   - After registration, you'll see the "Overview" page
   - Copy the **"Application (client) ID"** - you'll need this later

## Step 2: Configure API Permissions

1. **Navigate to API Permissions**
   - Click "API permissions" in the left sidebar

2. **Add Microsoft Graph Permissions**
   - Click "Add a permission"
   - Select "Microsoft Graph"
   - Select "Delegated permissions"
   - Search for and add these permissions:
     - ✅ `Files.Read` - Read user files
     - ✅ `Files.Read.All` - Read all files that user can access
     - ✅ `Sites.Read.All` - Read items in all site collections (for SharePoint)  
     - ✅ `User.Read` - Sign in and read user profile
   - Click "Add permissions"

3. **⚠️ IMPORTANT: Do NOT Grant Admin Consent**
   - Do NOT click "Grant admin consent for [organization]"
   - This would limit your app to only users in your organization
   - Leave permissions as "Not granted for [organization]" - this allows any user to consent

## Step 3: Get Chrome Extension Redirect URI

1. **Load your extension in Chrome**
   - Go to `chrome://extensions/`
   - Enable "Developer mode" (toggle in top right)
   - Click "Load unpacked" and select your extension folder
   - Note the extension ID in the card

2. **Get the Redirect URI**
   - Click your extension icon to open the side panel
   - Open Chrome Developer Tools (F12)
   - Go to Console tab
   - Look for a message like: `Chrome Extension Redirect URI for Azure setup: https://abcdefghijklmnop.chromiumapp.org/`
   - Copy this entire URL

## Step 4: Configure Authentication in Azure

1. **Go back to Azure Portal**
   - Navigate to your app > Authentication

2. **Add Platform**
   - Click "Add a platform"
   - Select "Single-page application"

3. **Add Redirect URI**
   - In the "Redirect URIs" field, paste the URL you copied from step 3
   - It should look like: `https://[your-extension-id].chromiumapp.org/`
   - Click "Configure"

4. **Verify Settings**
   - Under "Supported account types" should show "Multitenant and personal accounts"
   - Under "Redirect URIs" should show your Chrome extension URI

## Step 5: Configure Extension

1. **Update Client ID**
   - Open `/extension/config.js` in your code
   - Find the line: `CLIENT_ID: 'YOUR_MICROSOFT_APP_CLIENT_ID',`
   - Replace `'YOUR_MICROSOFT_APP_CLIENT_ID'` with your actual Client ID from Azure
   - Example: `CLIENT_ID: 'a1b2c3d4-e5f6-7890-abcd-ef1234567890',`

2. **Save and Reload Extension**
   - Save the file
   - Go to `chrome://extensions/`
   - Click the reload button for your extension

## Step 6: Test Authentication

1. **Open Extension**
   - Click your extension icon to open side panel

2. **Test Login**
   - Click "Connect OneDrive"
   - Should open Microsoft login popup
   - Sign in with any Microsoft account (personal, work, or school)
   - Grant permissions when prompted
   - Should redirect back to extension

3. **Test Folder Selection**
   - Should show user profile and "Select OneDrive Folder" button
   - Browse and select a folder
   - Click "Sync Files" to test file access

## Troubleshooting

### "unauthorized_client" Error
- **Problem**: Client ID not registered or incorrect
- **Solution**: Double-check Client ID in config.js matches Azure exactly

### "invalid_request" Error  
- **Problem**: Redirect URI not configured correctly
- **Solution**: Ensure redirect URI in Azure exactly matches the console output

### "Admin consent required" Error
- **Problem**: App restricted to single tenant
- **Solution**: In Azure, change to "Multitenant and personal accounts"

### "Access denied" Error
- **Problem**: Required permissions not added
- **Solution**: Add all permissions listed in Step 2, ensure NOT admin consented

### Extension doesn't load auth module
- **Problem**: config.js not loading properly
- **Solution**: Check browser console for JavaScript errors

## Security Notes

- ✅ **Multi-tenant**: Configured to accept any Microsoft account
- ✅ **No secrets**: Uses implicit flow (no client secret needed)
- ✅ **Secure storage**: Tokens stored in Chrome's secure storage
- ✅ **Limited scope**: Only requests necessary OneDrive permissions
- ✅ **User consent**: Each user must explicitly grant permissions

## Success Indicators

When properly configured, you should see:
1. No console warnings about "OneDrive authentication not configured"
2. "Connect OneDrive" button works without errors
3. Microsoft login popup appears and accepts any Microsoft account
4. After login, extension shows user profile and folder selection
5. Folder browsing works and shows user's OneDrive folders
6. File sync downloads files from selected folder

## Support

If you encounter issues:
1. Check browser console for error messages
2. Verify all steps above were followed exactly
3. Test with a different Microsoft account
4. Ensure extension is reloaded after config changes