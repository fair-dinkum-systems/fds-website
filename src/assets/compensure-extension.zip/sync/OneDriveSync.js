// ABOUTME: Handles OneDrive and SharePoint file synchronization and folder selection
// ABOUTME: Manages file downloads and local storage from OneDrive personal and SharePoint sites

class OneDriveSync {
  constructor(auth) {
    this.auth = auth;
    this.baseUrl = 'https://graph.microsoft.com/v1.0';
    this.selectedFolderKey = 'onedrive_sync_folder';
  }

  // Get root sources (OneDrive + SharePoint sites)
  async getRootSources() {
    const token = await this.auth.getAccessToken();
    if (!token) {
      throw new Error('Not authenticated');
    }
    
    try {
      // Get both OneDrive and SharePoint sites
      const [onedrive, sharepoint] = await Promise.all([
        this.getOneDriveInfo(),
        this.getSharePointSites()
      ]);
      
      return {
        onedrive,
        sharepoint
      };
    } catch (error) {
      console.error('Error fetching root sources:', error);
      throw error;
    }
  }

  // Get OneDrive personal info
  async getOneDriveInfo() {
    const token = await this.auth.getAccessToken();
    if (!token) {
      throw new Error('Not authenticated');
    }
    
    const response = await fetch(`${this.baseUrl}/me/drive`, {
      headers: { 
        'Authorization': `Bearer ${token}`,
        'Accept': 'application/json'
      }
    });
    
    if (!response.ok) {
      throw new Error(`Failed to get OneDrive info: ${response.status}`);
    }
    
    const drive = await response.json();
    return {
      id: drive.id,
      name: 'OneDrive Personal',
      type: 'onedrive',
      webUrl: drive.webUrl,
      owner: drive.owner
    };
  }

  // Get SharePoint sites user has access to
  async getSharePointSites() {
    const token = await this.auth.getAccessToken();
    if (!token) {
      throw new Error('Not authenticated');
    }
    
    try {
      const response = await fetch(`${this.baseUrl}/me/followedSites?$select=id,name,webUrl`, {
        headers: { 
          'Authorization': `Bearer ${token}`,
          'Accept': 'application/json'
        }
      });
      
      if (!response.ok) {
        // Try alternative endpoint for sites
        const altResponse = await fetch(`${this.baseUrl}/sites?search=*&$select=id,name,webUrl`, {
          headers: { 
            'Authorization': `Bearer ${token}`,
            'Accept': 'application/json'
          }
        });
        
        if (altResponse.ok) {
          const altData = await altResponse.json();
          return (altData.value || []).map(site => ({
            id: site.id,
            name: site.name,
            type: 'sharepoint',
            webUrl: site.webUrl
          }));
        }
        
        console.warn('SharePoint sites not accessible, continuing with OneDrive only');
        return [];
      }
      
      const data = await response.json();
      return (data.value || []).map(site => ({
        id: site.id,
        name: site.displayName || site.name,
        type: 'sharepoint',
        webUrl: site.webUrl
      }));
    } catch (error) {
      console.warn('Error fetching SharePoint sites:', error);
      return [];
    }
  }

  // Get document libraries for a SharePoint site
  async getSharePointLibraries(siteId) {
    const token = await this.auth.getAccessToken();
    if (!token) {
      throw new Error('Not authenticated');
    }
    
    const response = await fetch(`${this.baseUrl}/sites/${siteId}/drives`, {
      headers: { 
        'Authorization': `Bearer ${token}`,
        'Accept': 'application/json'
      }
    });
    
    if (!response.ok) {
      throw new Error(`Failed to get SharePoint libraries: ${response.status}`);
    }
    
    const data = await response.json();
    return (data.value || []).map(drive => ({
      id: drive.id,
      name: drive.name,
      type: 'library',
      webUrl: drive.webUrl,
      siteId: siteId
    }));
  }

  // Get list of folders from user's OneDrive
  async getRootFolders() {
    const token = await this.auth.getAccessToken();
    if (!token) {
      throw new Error('Not authenticated');
    }
    
    try {
      // Get root children
      const response = await fetch(`${this.baseUrl}/me/drive/root/children?$filter=folder ne null`, {
        headers: { 
          'Authorization': `Bearer ${token}`,
          'Accept': 'application/json'
        }
      });
      
      if (!response.ok) {
        throw new Error(`Failed to get folders: ${response.status}`);
      }
      
      const data = await response.json();
      return data.value || [];
    } catch (error) {
      console.error('Error fetching folders:', error);
      throw error;
    }
  }

  // Get children of a specific folder (OneDrive or SharePoint)
  async getFolderContents(context) {
    const token = await this.auth.getAccessToken();
    if (!token) {
      throw new Error('Not authenticated');
    }
    
    let url;
    if (context.source === 'sharepoint' && context.siteId && context.libraryId) {
      // SharePoint library folder
      if (context.folderId) {
        url = `${this.baseUrl}/sites/${context.siteId}/drives/${context.libraryId}/items/${context.folderId}/children`;
      } else {
        url = `${this.baseUrl}/sites/${context.siteId}/drives/${context.libraryId}/root/children`;
      }
    } else {
      // OneDrive folder
      if (context.folderId) {
        url = `${this.baseUrl}/me/drive/items/${context.folderId}/children`;
      } else {
        url = `${this.baseUrl}/me/drive/root/children`;
      }
    }
    
    const response = await fetch(url, {
      headers: { 
        'Authorization': `Bearer ${token}`,
        'Accept': 'application/json'
      }
    });
    
    if (!response.ok) {
      throw new Error(`Failed to get folder contents: ${response.status}`);
    }
    
    const data = await response.json();
    return data.value || [];
  }

  // Browse folders for selection (supports OneDrive and SharePoint)
  async browseFolders(context = { type: 'root' }) {
    const token = await this.auth.getAccessToken();
    if (!token) {
      throw new Error('Not authenticated');
    }
    
    try {
      if (context.type === 'root') {
        // Return root sources (OneDrive + SharePoint)
        return await this.getRootSources();
      } else if (context.type === 'onedrive') {
        // Browse OneDrive folders
        let url;
        if (context.folderId) {
          url = `${this.baseUrl}/me/drive/items/${context.folderId}/children?$filter=folder ne null`;
        } else {
          url = `${this.baseUrl}/me/drive/root/children?$filter=folder ne null`;
        }
        
        const response = await fetch(url, {
          headers: { 
            'Authorization': `Bearer ${token}`,
            'Accept': 'application/json'
          }
        });
        
        if (!response.ok) {
          throw new Error(`Failed to browse OneDrive folders: ${response.status}`);
        }
        
        const data = await response.json();
        return (data.value || []).map(item => ({
          ...item,
          source: 'onedrive'
        }));
        
      } else if (context.type === 'sharepoint') {
        if (context.siteId && !context.libraryId) {
          // Get document libraries for the SharePoint site
          return await this.getSharePointLibraries(context.siteId);
        } else if (context.siteId && context.libraryId) {
          // Browse folders within a SharePoint library
          let url;
          if (context.folderId) {
            url = `${this.baseUrl}/sites/${context.siteId}/drives/${context.libraryId}/items/${context.folderId}/children?$filter=folder ne null`;
          } else {
            url = `${this.baseUrl}/sites/${context.siteId}/drives/${context.libraryId}/root/children?$filter=folder ne null`;
          }
          
          const response = await fetch(url, {
            headers: { 
              'Authorization': `Bearer ${token}`,
              'Accept': 'application/json'
            }
          });
          
          if (!response.ok) {
            throw new Error(`Failed to browse SharePoint folders: ${response.status}`);
          }
          
          const data = await response.json();
          return (data.value || []).map(item => ({
            ...item,
            source: 'sharepoint',
            siteId: context.siteId,
            libraryId: context.libraryId
          }));
        }
      }
      
      return [];
    } catch (error) {
      console.error('Error browsing folders:', error);
      throw error;
    }
  }

  // Select a folder for synchronization
  async selectFolder(folder) {
    // Store selected folder info
    await chrome.storage.local.set({
      [this.selectedFolderKey]: {
        id: folder.id,
        name: folder.name,
        path: folder.parentReference?.path || '/',
        webUrl: folder.webUrl,
        selectedAt: new Date().toISOString()
      }
    });
    
    return true;
  }

  // Get currently selected folder
  async getSelectedFolder() {
    const data = await chrome.storage.local.get(this.selectedFolderKey);
    return data[this.selectedFolderKey] || null;
  }

  // Sync selected folder
  async syncSelectedFolder() {
    const folder = await this.getSelectedFolder();
    if (!folder) {
      throw new Error('No folder selected');
    }
    
    // Create context based on folder type
    const context = {
      source: folder.source || 'onedrive',
      folderId: folder.id,
      siteId: folder.siteId,
      libraryId: folder.libraryId
    };
    
    return await this.syncFolder(context);
  }

  // Sync a specific folder recursively (OneDrive or SharePoint)
  async syncFolder(context, path = '') {
    const token = await this.auth.getAccessToken();
    if (!token) {
      throw new Error('Not authenticated');
    }
    
    const items = await this.getFolderContents(context);
    const results = {
      files: [],
      folders: [],
      errors: []
    };
    
    for (const item of items) {
      try {
        if (item.file) {
          // It's a file - download it
          const fileData = await this.downloadFile(item, context);
          results.files.push({
            name: item.name,
            path: path + '/' + item.name,
            size: item.size,
            modified: item.lastModifiedDateTime,
            source: context.source || 'onedrive'
          });
          
          // Store file metadata for later use
          await this.storeFileMetadata(item, fileData, path, context);
        } else if (item.folder) {
          // It's a folder - recurse into it
          results.folders.push(item.name);
          
          // Create new context for subfolder
          const subContext = {
            ...context,
            folderId: item.id
          };
          
          const subResults = await this.syncFolder(subContext, path + '/' + item.name);
          results.files.push(...subResults.files);
          results.folders.push(...subResults.folders);
          results.errors.push(...subResults.errors);
        }
      } catch (error) {
        console.error(`Error syncing item ${item.name}:`, error);
        results.errors.push({ item: item.name, error: error.message });
      }
    }
    
    return results;
  }

  // Download a file from OneDrive or SharePoint
  async downloadFile(fileItem, context) {
    const token = await this.auth.getAccessToken();
    if (!token) {
      throw new Error('Not authenticated');
    }
    
    // Get download URL based on source
    let downloadUrl;
    if (context?.source === 'sharepoint' && context.siteId && context.libraryId) {
      downloadUrl = `${this.baseUrl}/sites/${context.siteId}/drives/${context.libraryId}/items/${fileItem.id}/content`;
    } else {
      downloadUrl = `${this.baseUrl}/me/drive/items/${fileItem.id}/content`;
    }
    
    const response = await fetch(downloadUrl, {
      headers: { 
        'Authorization': `Bearer ${token}`
      }
    });
    
    if (!response.ok) {
      throw new Error(`Failed to download file: ${response.status}`);
    }
    
    // Get file content
    const blob = await response.blob();
    return {
      blob,
      mimeType: fileItem.file?.mimeType,
      size: fileItem.size,
      name: fileItem.name
    };
  }

  // Store file metadata in chrome storage
  async storeFileMetadata(item, fileData, path, context) {
    // For now, store metadata in chrome.storage
    // In production, you'd want to use IndexedDB for actual file content
    const fileKey = `file_${item.id}`;
    
    await chrome.storage.local.set({
      [fileKey]: {
        id: item.id,
        name: item.name,
        path: path + '/' + item.name,
        size: item.size,
        mimeType: fileData.mimeType,
        lastModified: item.lastModifiedDateTime,
        downloadedAt: new Date().toISOString(),
        webUrl: item.webUrl,
        source: context?.source || 'onedrive',
        siteId: context?.siteId,
        libraryId: context?.libraryId,
        // Note: In production, store blob in IndexedDB
        // For demo, we're just storing metadata
      }
    });
  }

  // Get list of synced files
  async getSyncedFiles() {
    const allData = await chrome.storage.local.get();
    const files = [];
    
    for (const [key, value] of Object.entries(allData)) {
      if (key.startsWith('file_')) {
        files.push(value);
      }
    }
    
    return files;
  }

  // Clear all synced data
  async clearSyncedData() {
    const allData = await chrome.storage.local.get();
    const keysToRemove = [];
    
    for (const key of Object.keys(allData)) {
      if (key.startsWith('file_')) {
        keysToRemove.push(key);
      }
    }
    
    if (keysToRemove.length > 0) {
      await chrome.storage.local.remove(keysToRemove);
    }
    
    // Also clear selected folder
    await chrome.storage.local.remove(this.selectedFolderKey);
  }

  // Check if we have a folder selected
  async hasSelectedFolder() {
    const folder = await this.getSelectedFolder();
    return folder !== null;
  }

  // Test if we have write permissions by attempting to create a small test file
  async testWritePermissions() {
    const token = await this.auth.getAccessToken();
    if (!token) {
      throw new Error('Not authenticated');
    }
    
    const testFileName = `.compensure_write_test_${Date.now()}.tmp`;
    const testContent = 'test';
    
    try {
      // Try to create a test file in OneDrive root
      const uploadUrl = `${this.baseUrl}/me/drive/root:/${testFileName}:/content`;
      
      const response = await fetch(uploadUrl, {
        method: 'PUT',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'text/plain'
        },
        body: testContent
      });
      
      if (response.ok) {
        // Clean up test file
        try {
          const deleteUrl = `${this.baseUrl}/me/drive/root:/${testFileName}`;
          await fetch(deleteUrl, {
            method: 'DELETE',
            headers: { 'Authorization': `Bearer ${token}` }
          });
        } catch (e) {
          // Ignore cleanup errors
        }
        return { hasWriteAccess: true };
      } else {
        const error = await response.json();
        return { 
          hasWriteAccess: false, 
          error: error.error?.message || `HTTP ${response.status}`,
          code: error.error?.code
        };
      }
    } catch (error) {
      return { 
        hasWriteAccess: false, 
        error: error.message 
      };
    }
  }
}

// Export for use in extension
if (typeof module !== 'undefined' && module.exports) {
  module.exports = OneDriveSync;
}