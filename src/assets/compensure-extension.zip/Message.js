// ABOUTME: Unified Message class for both conversation messages and task messages
// ABOUTME: Combines ConversationMessage and TaskMessage functionality

class Message {
    constructor(id, type, content, timestamp, taskId = null) {
        // ConversationMessage fields
        this.id = id;
        this.type = type; // 'user_message', 'assistant_message', 'task_message', etc.
        this.content = content;
        this.timestamp = timestamp;
        this.task_id = taskId;
        
        // TaskMessage compatibility - if it's a task message, also expose as 'message' field
        if (type === 'task_message') {
            this.message = content;
        }
    }

    static fromJSON(json) {
        // Handle both ConversationMessage and TaskMessage formats
        if (json.message && !json.content) {
            // TaskMessage format
            return new Message(
                json.id || 'msg-' + Date.now(),
                'task_message',
                json.message,
                json.timestamp,
                json.task_id || null
            );
        } else {
            // ConversationMessage format
            return new Message(
                json.id,
                json.type,
                json.content,
                json.timestamp,
                json.task_id || null
            );
        }
    }

    toJSON() {
        const base = {
            id: this.id,
            type: this.type,
            content: this.content,
            timestamp: this.timestamp,
            task_id: this.task_id
        };
        
        // Add TaskMessage compatibility field
        if (this.type === 'task_message') {
            base.message = this.content;
        }
        
        return base;
    }
}

// Export for both Node.js (testing) and browser
if (typeof module !== 'undefined' && module.exports) {
    module.exports = Message;
} else {
    window.Message = Message;
}