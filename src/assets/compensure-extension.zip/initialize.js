// ABOUTME: Handles initialize screen with OneDrive folder selection
// ABOUTME: Manages folder browsing, selection, and file synchronization

document.addEventListener('DOMContentLoaded', function() {
    // DOM elements
    const logoutBtn = document.getElementById('logoutBtn');
    const chatBtn = document.getElementById('chatBtn');
    const selectFolderBtn = document.getElementById('selectFolderBtn');
    const confirmFolderBtn = document.getElementById('confirmFolderBtn');
    const changeFolderBtn = document.getElementById('changeFolderBtn');
    const folderPicker = document.getElementById('folderPicker');
    const folderList = document.getElementById('folderList');
    const breadcrumb = document.getElementById('breadcrumb');
    const userInfo = document.getElementById('userInfo');
    const userName = document.getElementById('userName');
    const userEmail = document.getElementById('userEmail');
    const selectedFolderInfo = document.getElementById('selectedFolderInfo');
    const selectedFolderName = document.getElementById('selectedFolderName');
    const workerStatus = document.getElementById('workerStatus');
    const workerStatusText = document.getElementById('workerStatusText');
    const claudeAuthSection = document.getElementById('claudeAuthSection');
    const claudeAuthStatusText = document.getElementById('claudeAuthStatusText');
    const claudeAuthUrl = document.getElementById('claudeAuthUrl');
    const claudeAuthLink = document.getElementById('claudeAuthLink');
    const claudeAuthCodeInput = document.getElementById('claudeAuthCodeInput');
    const claudeAuthCode = document.getElementById('claudeAuthCode');
    const claudeAuthSubmit = document.getElementById('claudeAuthSubmit');
    
    let auth = null;
    let sync = null;
    let workerManager = null;
    let currentPath = [];
    let currentContext = { type: 'root' };
    let selectedFolder = null;
    
    // Load authentication modules
    const authScript = document.createElement('script');
    authScript.src = 'auth/OneDriveAuth.js';
    document.head.appendChild(authScript);
    
    authScript.onload = function() {
        const syncScript = document.createElement('script');
        syncScript.src = 'sync/OneDriveSync.js';
        document.head.appendChild(syncScript);
        
        syncScript.onload = function() {
            const storageScript = document.createElement('script');
            storageScript.src = 'StoragePersistence.js';
            document.head.appendChild(storageScript);
            
            storageScript.onload = function() {
                const workerScript = document.createElement('script');
                workerScript.src = 'WorkerManager.js';
                document.head.appendChild(workerScript);
                
                workerScript.onload = function() {
                    auth = new OneDriveAuth();
                    sync = new OneDriveSync(auth);
                    workerManager = new WorkerManager(auth);
                        
                    initialize();
                };
            };
        };
    };
    
    async function initialize() {
        try {
            // Check authentication
            const isAuth = await auth.isAuthenticated();
            if (!isAuth) {
                // Not authenticated, go back to login
                await chrome.storage.local.set({
                    appState: {
                        stage: 'login',
                        timestamp: Date.now()
                    }
                });
                window.location.replace('login.html');
                return;
            }
            
            // Show user info
            const user = await auth.getUser();
            if (user) {
                userName.textContent = user.displayName || 'User';
                userEmail.textContent = user.mail || user.userPrincipalName || '';
                userInfo.style.display = 'block';
            }
            
            // Check if folder already selected
            const existingFolder = await sync.getSelectedFolder();
            if (existingFolder) {
                selectedFolder = existingFolder;
                await initializeWorker();
            } else {
                // Show folder selection button
                selectFolderBtn.style.display = 'block';
            }
            
        } catch (error) {
            console.error('Initialization error:', error);
            alert('Failed to initialize. Please try logging in again.');
            await auth.signOut();
            window.location.replace('login.html');
        }
    }
    
    // Show selected folder info - only show chat button if worker is ready and Claude authenticated
    function showSelectedFolder() {
        if (!selectedFolder) {
            console.warn('showSelectedFolder called but no folder is selected');
            return;
        }
        selectedFolderName.textContent = selectedFolder.name;
        selectedFolderInfo.style.display = 'block';
        folderPicker.classList.remove('active');
        selectFolderBtn.style.display = 'none';
        confirmFolderBtn.style.display = 'none';
        changeFolderBtn.style.display = 'block';
        
        // Only show chat button if worker is ready (active + Claude authenticated)
        if (workerManager && workerManager.isWorkerReady()) {
            chatBtn.style.display = 'block';
        }
    }
    
    // Start folder selection
    selectFolderBtn.addEventListener('click', async function() {
        selectFolderBtn.style.display = 'none';
        folderPicker.classList.add('active');
        confirmFolderBtn.style.display = 'block';
        await loadFolders();
    });
    
    // Change folder
    changeFolderBtn.addEventListener('click', async function() {
        selectedFolder = null;
        // Worker state is managed by workerManager, no local variables to reset
        selectedFolderInfo.style.display = 'none';
        changeFolderBtn.style.display = 'none';
        chatBtn.style.display = 'none';
        workerStatus.classList.remove('visible');
        claudeAuthSection.style.display = 'none';
        folderPicker.classList.add('active');
        confirmFolderBtn.style.display = 'block';
        await loadFolders();
    });
    
    // Load folders for browsing
    async function loadFolders(context = { type: 'root' }) {
        try {
            folderList.innerHTML = '<li style="color: #666;">Loading...</li>';
            currentContext = context;
            
            const result = await sync.browseFolders(context);
            
            folderList.innerHTML = '';
            
            if (context.type === 'root') {
                // Show OneDrive and SharePoint sources
                await displayRootSources(result);
            } else if (context.type === 'sharepoint' && !context.libraryId) {
                // Show SharePoint document libraries
                await displaySharePointLibraries(result);
            } else {
                // Show regular folders
                await displayFolders(result);
            }
            
        } catch (error) {
            console.error('Error loading folders:', error);
            folderList.innerHTML = '<li style="color: #f00;">Failed to load content</li>';
        }
    }
    
    // Display root sources (OneDrive + SharePoint sites)
    async function displayRootSources(sources) {
        // OneDrive Personal
        if (sources.onedrive) {
            const li = createSourceItem(sources.onedrive, 'OneDrive', '☁️');
            folderList.appendChild(li);
        }
        
        // SharePoint Sites
        if (sources.sharepoint && sources.sharepoint.length > 0) {
            sources.sharepoint.forEach(site => {
                const li = createSourceItem(site, site.name, '🏢');
                folderList.appendChild(li);
            });
        }
        
        if (!sources.onedrive && (!sources.sharepoint || sources.sharepoint.length === 0)) {
            folderList.innerHTML = '<li style="color: #666;">No accessible sources found</li>';
        }
    }
    
    // Create a source item (OneDrive or SharePoint site)
    function createSourceItem(source, name, icon) {
        const li = document.createElement('li');
        li.className = 'folder-item source-item';
        li.dataset.sourceId = source.id;
        li.dataset.sourceType = source.type;
        
        li.innerHTML = `
            <span class="folder-icon">${icon}</span>
            <span>${name}</span>
            <span class="source-badge ${source.type}-badge">${source.type.toUpperCase()}</span>
        `;
        
        // Single-click to select source as root folder
        li.addEventListener('click', async function(e) {
            e.stopPropagation();
            selectItem(li, {
                id: source.id,
                name: name,
                type: 'source',
                source: source.type,
                isRoot: true
            });
        });
        
        // Double-click to browse into source
        li.addEventListener('dblclick', async function(e) {
            e.stopPropagation();
            
            if (source.type === 'onedrive') {
                currentPath.push({ name: name, type: 'onedrive' });
                updateBreadcrumb();
                await loadFolders({ type: 'onedrive' });
            } else if (source.type === 'sharepoint') {
                currentPath.push({ name: name, type: 'sharepoint', siteId: source.id });
                updateBreadcrumb();
                await loadFolders({ type: 'sharepoint', siteId: source.id });
            }
        });
        
        return li;
    }
    
    // Display SharePoint document libraries
    async function displaySharePointLibraries(libraries) {
        if (!libraries || libraries.length === 0) {
            folderList.innerHTML = '<li style="color: #666;">No document libraries found</li>';
            return;
        }
        
        libraries.forEach(library => {
            const li = document.createElement('li');
            li.className = 'folder-item library-item';
            li.dataset.libraryId = library.id;
            li.dataset.libraryName = library.name;
            li.dataset.siteId = library.siteId;
            
            li.innerHTML = `
                <span class="folder-icon">📚</span>
                <span>${library.name}</span>
                <span class="source-badge sharepoint-badge">LIBRARY</span>
            `;
            
            // Click to select library
            li.addEventListener('click', async function(e) {
                e.stopPropagation();
                selectItem(li, {
                    id: library.id,
                    name: library.name,
                    type: 'library',
                    source: 'sharepoint',
                    siteId: library.siteId,
                    libraryId: library.id
                });
            });
            
            // Double-click to browse into library
            li.addEventListener('dblclick', async function(e) {
                e.stopPropagation();
                currentPath.push({ name: library.name, type: 'library', siteId: library.siteId, libraryId: library.id });
                updateBreadcrumb();
                await loadFolders({
                    type: 'sharepoint',
                    siteId: library.siteId,
                    libraryId: library.id
                });
            });
            
            folderList.appendChild(li);
        });
    }
    
    // Display regular folders
    async function displayFolders(folders) {
        if (!folders || folders.length === 0) {
            folderList.innerHTML = '<li style="color: #666;">No folders found</li>';
            // Update button text to indicate current folder can be used
            if (currentContext.type !== 'root') {
                confirmFolderBtn.textContent = `Use Current Folder`;
                confirmFolderBtn.disabled = false;
            }
            return;
        }
        
        folders.forEach(folder => {
            const li = document.createElement('li');
            li.className = 'folder-item';
            li.dataset.folderId = folder.id;
            li.dataset.folderName = folder.name;
            
            li.innerHTML = `
                <span class="folder-icon">📁</span>
                <span>${folder.name}</span>
            `;
            
            // Click to select folder
            li.addEventListener('click', async function(e) {
                e.stopPropagation();
                selectItem(li, {
                    id: folder.id,
                    name: folder.name,
                    type: 'folder',
                    source: folder.source || currentContext.type === 'onedrive' ? 'onedrive' : 'sharepoint',
                    siteId: folder.siteId || currentContext.siteId,
                    libraryId: folder.libraryId || currentContext.libraryId
                });
            });
            
            // Double-click to browse into folder
            li.addEventListener('dblclick', async function(e) {
                e.stopPropagation();
                
                const newPath = { name: folder.name, type: 'folder', folderId: folder.id };
                if (currentContext.siteId) newPath.siteId = currentContext.siteId;
                if (currentContext.libraryId) newPath.libraryId = currentContext.libraryId;
                
                currentPath.push(newPath);
                updateBreadcrumb();
                
                const newContext = {
                    ...currentContext,
                    folderId: folder.id
                };
                await loadFolders(newContext);
            });
            
            folderList.appendChild(li);
        });
    }
    
    // Select an item (folder or library)
    function selectItem(li, item) {
        // If already selected, deselect
        if (li.classList.contains('selected')) {
            li.classList.remove('selected');
            selectedFolder = null;
            confirmFolderBtn.textContent = currentContext.type === 'root' ? 'Use Selected Folder' : 'Use Current Folder';
            confirmFolderBtn.disabled = false;  // Keep enabled to show helpful message
            return;
        }
        
        // Clear other selections
        document.querySelectorAll('.folder-item').forEach(item => {
            item.classList.remove('selected');
        });
        
        // Select this item
        li.classList.add('selected');
        selectedFolder = item;
        confirmFolderBtn.textContent = `Use "${item.name}"`;
        confirmFolderBtn.disabled = false;
    }
    
    // Update breadcrumb navigation
    function updateBreadcrumb() {
        breadcrumb.innerHTML = '';
        
        // Root
        const rootSpan = document.createElement('span');
        rootSpan.className = 'breadcrumb-item';
        rootSpan.textContent = 'Sources';
        rootSpan.addEventListener('click', async function() {
            currentPath = [];
            currentContext = { type: 'root' };
            updateBreadcrumb();
            await loadFolders({ type: 'root' });
        });
        breadcrumb.appendChild(rootSpan);
        
        // Path items
        currentPath.forEach((item, index) => {
            // Separator
            const sep = document.createElement('span');
            sep.className = 'breadcrumb-separator';
            sep.textContent = ' / ';
            breadcrumb.appendChild(sep);
            
            // Item
            const span = document.createElement('span');
            span.className = 'breadcrumb-item';
            span.textContent = item.name;
            span.addEventListener('click', async function() {
                // Trim path to this point
                currentPath = currentPath.slice(0, index + 1);
                updateBreadcrumb();
                
                // Create appropriate context for navigation
                const pathToHere = currentPath.slice(0, index + 1);
                let navContext = { type: 'root' };
                
                if (item.type === 'onedrive') {
                    navContext = { type: 'onedrive' };
                } else if (item.type === 'sharepoint') {
                    navContext = { type: 'sharepoint', siteId: item.siteId };
                } else if (item.type === 'library') {
                    navContext = { type: 'sharepoint', siteId: item.siteId, libraryId: item.libraryId };
                } else if (item.type === 'folder') {
                    // Find the context from earlier path items
                    let contextFromPath = { type: 'root' };
                    for (let i = index - 1; i >= 0; i--) {
                        if (pathToHere[i].type === 'onedrive') {
                            contextFromPath = { type: 'onedrive' };
                            break;
                        } else if (pathToHere[i].type === 'sharepoint') {
                            contextFromPath = { type: 'sharepoint', siteId: pathToHere[i].siteId };
                            break;
                        } else if (pathToHere[i].type === 'library') {
                            contextFromPath = { 
                                type: 'sharepoint', 
                                siteId: pathToHere[i].siteId, 
                                libraryId: pathToHere[i].libraryId 
                            };
                            break;
                        }
                    }
                    navContext = { ...contextFromPath, folderId: item.folderId };
                }
                
                currentContext = navContext;
                await loadFolders(navContext);
            });
            breadcrumb.appendChild(span);
        });
    }
    

    // Poll worker status and update UI accordingly
    async function pollWorkerStatus() {
        const maxAttempts = 60; // 5 minutes at 5-second intervals
        let attempts = 0;
        let statusUpdateInterval = null;
        
        // Start fast UI updates (12ms intervals) for loading status
        statusUpdateInterval = setInterval(() => {
            try {
                const status = workerManager.getWorkerStatus();
                if (status.status !== 'active' && status.status !== 'failed') {
                    const loadingStatus = workerManager.getLoadingStatus();
                    if (loadingStatus.message) {
                        workerStatusText.textContent = loadingStatus.message;
                    }
                }
            } catch (error) {
                // Ignore errors during UI updates
            }
        }, 31); // Update UI every 12ms for very smooth counting
        
        const pollInterval = setInterval(async () => {
            attempts++;
            
            try {
                const status = workerManager.getWorkerStatus();
                const claudeAuthState = workerManager.getClaudeAuthState();
                
                if (status.status === 'active') {
                    workerStatusText.textContent = 'Authenticating with Claude...';
                    clearInterval(pollInterval);
                    clearInterval(statusUpdateInterval);
                    
                    // Start Claude authentication process
                    startClaudeAuthFlow();
                    
                } else if (status.status === 'failed') {
                    workerStatusText.textContent = 'Worker failed to start';
                    clearInterval(pollInterval);
                    clearInterval(statusUpdateInterval);
                    setTimeout(() => {
                        workerStatus.classList.remove('visible');
                    }, 5000);
                    
                } else if (attempts >= maxAttempts) {
                    workerStatusText.textContent = 'Worker creation timed out';
                    clearInterval(pollInterval);
                    clearInterval(statusUpdateInterval);
                    setTimeout(() => {
                        workerStatus.classList.remove('visible');
                    }, 5000);
                }
                
                // Advance to next loading word every few polls
                if (attempts % 3 === 0) {
                    workerManager.nextLoadingWord();
                }
                
            } catch (error) {
                console.error('Error polling worker status:', error);
            }
        }, 5000); // Poll every 5 seconds
    }
    
    // Initialize worker (creates if needed, syncs files)
    async function initializeWorker() {
        try {
            workerStatus.classList.add('visible');
            workerStatusText.textContent = 'Initializing worker...';
            
            try {
                await workerManager.initialize();
                const result = await workerManager.createWorker();
                
                pollWorkerStatus();
                
                return result;
                
            } catch (error) {
                console.error('Error creating worker:', error);
                throw error;
            }
            
        } catch (error) {
            console.error('Error initializing worker:', error);
            
            // Check if this is a worker limit error
            if (error.status === 400 && error.errorData && error.errorData.error && 
                error.errorData.error.toLowerCase().includes('worker limit')) {
                workerStatusText.textContent = `Worker limit exceeded (${error.errorData.current_worker_count}/${error.errorData.max_workers}). Please clean up existing workers first.`;
            } else {
                workerStatusText.textContent = error.message || 'Failed to create worker';
            }
            
            setTimeout(() => {
                workerStatus.classList.remove('visible');
            }, 8000); // Show error longer for worker limit
        }
    }

    // Confirm folder selection
    confirmFolderBtn.addEventListener('click', async function() {
        if (!selectedFolder && currentContext.type === 'root') {
            alert('Please select a folder first');
            return;
        }
        
        // Use current folder if no subfolder is selected
        const folderToUse = selectedFolder || currentContext;
        
        try {
            confirmFolderBtn.disabled = true;
            confirmFolderBtn.textContent = 'Saving...';
            
            await sync.selectFolder(folderToUse);
            
            // Initialize worker after folder selection
            await initializeWorker();
            
        } catch (error) {
            console.error('Error selecting folder:', error);
            alert('Failed to select folder. Please try again.');
            confirmFolderBtn.disabled = false;
            confirmFolderBtn.textContent = `Use "${selectedFolder.name}"`;
        }
    });
    
    
    // Handle logout
    logoutBtn.addEventListener('click', async function() {
        try {
            if (confirm('Are you sure you want to sign out? This will disconnect your OneDrive account.')) {
                await auth.signOut();
                window.location.replace('login.html');
            }
        } catch (error) {
            console.error('Error during logout:', error);
            alert('Logout failed. Please try again.');
        }
    });
    
    // Handle chat navigation
    chatBtn.addEventListener('click', async function() {
        try {
            // Ensure we have a selected folder
            if (!selectedFolder) {
                alert('Please select a OneDrive folder first');
                return;
            }
            
            // Transition to chat stage
            await chrome.storage.local.set({
                appState: {
                    stage: 'chat',
                    timestamp: Date.now()
                }
            });
            
            // Navigate to chat screen
            window.location.replace('sidepanel.html');
        } catch (error) {
            console.error('Error navigating to chat:', error);
            alert('Failed to open chat. Please try again.');
        }
    });

    // Claude Authentication Functions
    async function startClaudeAuthFlow() {
        try {
            // Ensure we have a worker token before starting Claude auth
            if (!workerManager.getWorkerToken()) {
                throw new Error('Cannot start Claude authentication without a valid worker token');
            }
            
            claudeAuthSection.style.display = 'block';
            workerStatus.classList.remove('visible');  // Hide worker status during claude auth phase
            workerStatusText.textContent = 'Checking Claude authentication...';
            claudeAuthStatusText.textContent = 'Checking Claude authentication...';
            
            // Start polling Claude auth status
            pollClaudeAuthStatus();
            
        } catch (error) {
            console.error('Error starting Claude auth flow:', error);
            workerStatusText.textContent = 'Failed to check Claude authentication';
            claudeAuthStatusText.textContent = 'Failed to check Claude authentication';
        }
    }
    
    // Poll Claude authentication status
    async function pollClaudeAuthStatus() {
        console.log('Polling Claude authentication status...');
        try {
            // Double-check we have a worker token before making auth requests
            if (!workerManager.getWorkerToken()) {
                throw new Error('Cannot poll Claude authentication without a valid worker token')
            }
            
            const currentState = await workerManager.checkClaudeAuthStatus();
            
            if (currentState === 'TABULA_RASA') {
                // Need to get login URL
                workerStatusText.textContent = 'Getting Claude login URL...';
                claudeAuthStatusText.textContent = 'Getting Claude login URL...';
                claudeAuthUrl.style.display = 'none';
                claudeAuthCodeInput.style.display = 'none';
                
                try {
                    const loginUrl = await workerManager.getClaudeLoginUrl();
                    handleClaudeAuthStateChange('URL_OBTAINED', loginUrl);
                } catch (error) {
                    console.error('Error getting Claude login URL:', error);
                    workerStatusText.textContent = `Failed to get login URL: ${error.message}`;
                    claudeAuthStatusText.textContent = `Failed to get login URL: ${error.message}`;
                }
                
            } else if (currentState === 'URL_OBTAINED') {
                // URL should already be available
                const loginUrl = workerManager.claudeOAuthUrl;
                if (loginUrl) {
                    handleClaudeAuthStateChange('URL_OBTAINED', loginUrl);
                } else {
                    throw new Error(`Claude login URL is missing despite state being URL_OBTAINED ${currentState}`);
                }
            } else if (currentState === 'AUTHENTICATED') {
                // Auth complete, show chat button
                handleClaudeAuthStateChange('AUTHENTICATED');
                
            } else {
                // Continue polling for other states
                setTimeout(pollClaudeAuthStatus, 2000);
            }
            
        } catch (error) {
            console.error('Error polling Claude auth status:', error);
            
            // If it's an authentication error, check if worker token is missing/invalid
            if (error.message && error.message.includes('401')) {
                console.error('Authentication failed - worker token may be missing or invalid');
                workerStatusText.textContent = 'Authentication failed - please refresh and try again';
                claudeAuthStatusText.textContent = 'Authentication failed - please refresh and try again';
                return; // Don't retry for auth failures
            }
            
            setTimeout(pollClaudeAuthStatus, 5000); // Retry after other errors
        }
    }

    function handleClaudeAuthStateChange(state, loginUrl = null) {
        console.log('Handling Claude auth state change:', state, loginUrl);
        
        switch (state) {
            case 'URL_OBTAINED':
                if (loginUrl) {
                    // Update worker status to show waiting for user action
                    workerStatusText.textContent = 'Waiting for Claude authentication...';
                    claudeAuthStatusText.textContent = 'Please authenticate with Claude Code';
                    claudeAuthLink.href = loginUrl;
                    claudeAuthUrl.style.display = 'block';
                    claudeAuthCodeInput.style.display = 'block';
                }
                break;
                
            case 'AUTHENTICATED':
                // Hide both status areas and show the chat button
                workerStatus.classList.remove('visible');
                claudeAuthSection.style.display = 'none';
                showSelectedFolder(); // This will show chat button if worker is ready
                break;
        }
    }

    // Claude auth code submission
    claudeAuthSubmit.addEventListener('click', async function() {
        const code = claudeAuthCode.value.trim();
        if (!code) {
            alert('Please enter the authentication code');
            return;
        }

        try {
            claudeAuthSubmit.disabled = true;
            claudeAuthSubmit.textContent = 'Submitting...';
            // Update both status areas
            workerStatusText.textContent = 'Submitting authentication code...';
            claudeAuthStatusText.textContent = 'Submitting authentication code...';
            
            await workerManager.authenticateClaudeWithCode(code);
            
            // Check auth status to see if it succeeded
            const newState = await workerManager.checkClaudeAuthStatus();
            if (newState === 'AUTHENTICATED') {
                handleClaudeAuthStateChange('AUTHENTICATED');
            } else {
                // Continue polling to check status
                setTimeout(pollClaudeAuthStatus, 1000);
            }
            
        } catch (error) {
            console.error('Error submitting Claude auth code:', error);
            workerStatusText.textContent = `Authentication failed: ${error.message}`;
            claudeAuthStatusText.textContent = `Authentication failed: ${error.message}`;
            claudeAuthSubmit.disabled = false;
            claudeAuthSubmit.textContent = 'Submit Code';
        }
    });
});