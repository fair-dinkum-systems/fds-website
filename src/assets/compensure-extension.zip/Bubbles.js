// core function
function Bubbles(container, self, options) {
  // options
  options = typeof options !== "undefined" ? options : {}
  animationTime = options.animationTime || 100 // how long it takes to animate chat bubble, also set in CSS
  typeSpeed = options.typeSpeed || 5 // delay per character, to simulate the machine "typing"
  widerBy = options.widerBy || 2 // add a little extra width to bubbles to make sure they don't break
  sidePadding = options.sidePadding || 6 // padding on both sides of chat bubbles
  recallInteractions = options.recallInteractions || 0 // number of interactions to be remembered and brought back upon restart
  inputCallbackFn = options.inputCallbackFn || false // should we display an input field?
  responseCallbackFn = options.responseCallbackFn || false // is there a callback function for when a user clicks on a bubble button

  var standingAnswer = "ice" // remember where to restart convo if interrupted
  var inputTextArea = null // reference to the input textarea for auto-focus functionality

  var _convo = {} // local memory for conversation JSON object
  //--> NOTE that this object is only assigned once, per session and does not change for this
  // 		constructor name during open session.

  // local storage for recalling conversations upon restart
  var localStorageCheck = function() {
    var test = "chat-bubble-storage-test"
    try {
      localStorage.setItem(test, test)
      localStorage.removeItem(test)
      return true
    } catch (error) {
      console.error(
        "Your server does not allow storing data locally. Most likely it's because you've opened this page from your hard-drive. For testing you can disable your browser's security or start a local environment."
      )
      return false
    }
  }
  var localStorageAvailable = localStorageCheck() && recallInteractions > 0
  var interactionsLS = "chat-bubble-interactions"
  var interactionsHistory =
    (localStorageAvailable &&
      JSON.parse(localStorage.getItem(interactionsLS))) ||
    []

  // prepare next save point
  interactionsSave = function(say, reply) {
    if (!localStorageAvailable) return
    // limit number of saves
    if (interactionsHistory.length > recallInteractions)
      interactionsHistory.shift() // removes the oldest (first) save to make space

    // do not memorize buttons; only user input gets memorized:
    if (
      // `bubble-button` class name signals that it's a button
      say.includes("bubble-button") &&
      // if it is not of a type of textual reply
      reply !== "reply reply-freeform" &&
      // if it is not of a type of textual reply or memorized user choice
      reply !== "reply reply-pick"
    )
      // ...it shan't be memorized
      return

    // save to memory
    interactionsHistory.push({ say: say, reply: reply })
  }

  // commit save to localStorage
  interactionsSaveCommit = function() {
    if (!localStorageAvailable) return
    localStorage.setItem(interactionsLS, JSON.stringify(interactionsHistory))
  }

  // set up the stage
  container.classList.add("bubble-container")
  var bubbleWrap = document.createElement("div")
  bubbleWrap.className = "bubble-wrap"
  container.appendChild(bubbleWrap)

  // install user input textfield
  this.typeInput = function(callbackFn) {
    var inputWrap = document.createElement("div")
    inputWrap.className = "input-wrap"
    var inputText = document.createElement("textarea")
    inputText.setAttribute("placeholder", "...")
    inputWrap.appendChild(inputText)
    
    // Store reference to input for auto-focus functionality
    inputTextArea = inputText
    
    // auto-resize textarea based on content
    function autoResize() {
      inputText.style.height = 'auto'
      var maxHeight = 6 * 1.25 * 16 + 20 // 6 lines * line-height * font-size + padding
      inputText.style.height = Math.min(inputText.scrollHeight, maxHeight) + 'px'
    }
    
    inputText.addEventListener('input', autoResize)
    inputText.addEventListener('paste', function() {
      setTimeout(autoResize, 0)
    })
    inputText.addEventListener("keypress", function(e) {
      // register user input
      if (e.keyCode == 13 && !e.shiftKey) {
        e.preventDefault()
        typeof bubbleQueue !== false ? clearTimeout(bubbleQueue) : false // allow user to interrupt the bot
        var lastBubble = document.querySelectorAll(".bubble.say")
        lastBubble = lastBubble[lastBubble.length - 1]
        lastBubble && lastBubble.classList.contains("reply") &&
        !lastBubble.classList.contains("reply-freeform")
          ? lastBubble.classList.add("bubble-hidden")
          : false
        addBubble(
          '<div class="bubble-button bubble-pick">' + this.value + "</div>",
          function() {},
          "reply reply-freeform"
        )
        // callback
        typeof callbackFn === "function"
          ? callbackFn({
              input: this.value,
              convo: _convo,
              standingAnswer: standingAnswer
            })
          : false
        this.value = ""
      }
    })
    container.appendChild(inputWrap)
    bubbleWrap.style.paddingBottom = "100px"
    inputText.focus()
  }
  inputCallbackFn ? this.typeInput(inputCallbackFn) : false

  // init typing bubble
  var bubbleTyping = document.createElement("div")
  bubbleTyping.className = "bubble-typing imagine"
  for (dots = 0; dots < 3; dots++) {
    var dot = document.createElement("div")
    dot.className = "dot_" + dots + " dot"
    bubbleTyping.appendChild(dot)
  }
  bubbleWrap.appendChild(bubbleTyping)

  // accept JSON & create bubbles
  this.talk = function(convo, here) {
    // all further .talk() calls will append the conversation with additional blocks defined in convo parameter
    _convo = Object.assign(_convo, convo) // POLYFILL REQUIRED FOR OLDER BROWSERS

    this.reply(_convo[here])
    here ? (standingAnswer = here) : false
  }

  var iceBreaker = false // this variable holds answer to whether this is the initative bot interaction or not
  this.reply = function(turn) {
    console.log('[BUBBLES] reply() called with turn:', turn);
    iceBreaker = typeof turn === "undefined"
    turn = !iceBreaker ? turn : _convo.ice
    questionsHTML = ""
    if (!turn) {
      console.log('[BUBBLES] turn is null/undefined, returning early');
      return;
    }
    
    if (turn.says && turn.says.length > 0) {
      console.log('[BUBBLES] Processing', turn.says.length, 'messages');
      for (let i = 0; i < turn.says.length; i++) {
        console.log(`[BUBBLES] Message ${i} length: ${turn.says[i].length}`);
        console.log(`[BUBBLES] Message ${i} preview: ${turn.says[i].substring(0, 100)}...`);
      }
    }
    if (turn.reply !== undefined) {
      turn.reply.reverse()
      for (var i = 0; i < turn.reply.length; i++) {
        ;(function(el, count) {
          questionsHTML +=
            '<span class="bubble-button" style="animation-delay: ' +
            animationTime / 2 * count +
            'ms" onClick="' +
            self +
            ".answer('" +
            el.answer +
            "', '" +
            el.question +
            "');this.classList.add('bubble-pick')\">" +
            el.question +
            "</span>"
        })(turn.reply[i], i)
      }
    }
    orderBubbles(turn.says, function() {
      bubbleTyping.classList.remove("imagine")
      questionsHTML !== ""
        ? addBubble(questionsHTML, function() {}, "reply")
        : bubbleTyping.classList.add("imagine")
      
      // Auto-focus input after assistant reply if input is enabled and textarea is not disabled
      if (turn.input === true && inputTextArea && !inputTextArea.disabled) {
        // Use setTimeout to ensure DOM updates are complete before focusing
        setTimeout(() => {
          if (inputTextArea && !inputTextArea.disabled) {
            inputTextArea.focus()
          }
        }, 50)
      }
    })
  }
  // navigate "answers"
  this.answer = function(key, content) {
    var func = function(key, content) {
      typeof window[key] === "function" ? window[key](content) : false
    }
    _convo[key] !== undefined
      ? (this.reply(_convo[key]), (standingAnswer = key))
      : (typeof responseCallbackFn === 'function' ? responseCallbackFn({input: key,convo: _convo,standingAnswer: standingAnswer}, key) : func(key, content))

    // add re-generated user picks to the history stack
    if (_convo[key] !== undefined && content !== undefined) {
      interactionsSave(
        '<span class="bubble-button reply-pick">' + content + "</span>",
        "reply reply-pick"
      )
    }
  }

  // api for typing bubble
  this.think = function() {
    bubbleTyping.classList.remove("imagine")
    this.stop = function() {
      bubbleTyping.classList.add("imagine")
    }
  }

  // expose addBubble for external use (e.g., displaying stored messages)
  this.addStoredBubble = function(content, replyType) {
    addBubble(content, function() {}, replyType || "", true) // false = not live (no animation)
  }

  // "type" each message within the group
  var orderBubbles = function(q, callback) {
    var start = function() {
      setTimeout(function() {
        callback()
      }, animationTime)
    }
    var position = 0
    for (
      var nextCallback = position + q.length - 1;
      nextCallback >= position;
      nextCallback--
    ) {
      ;(function(callback, index) {
        start = function() {
          addBubble(q[index], callback)
        }
      })(start, nextCallback)
    }
    start()
  }

  // create a bubble
  var bubbleQueue = false
  var addBubble = function(say, posted, reply, live) {
    console.log(`[BUBBLES] addBubble called with message length: ${say.length}`);
    console.log(`[BUBBLES] addBubble message preview: ${say.substring(0, 100)}...`);
    
    reply = typeof reply !== "undefined" ? reply : ""
    live = typeof live !== "undefined" ? live : true // bubbles that are not "live" are not animated and displayed differently
    var localAnimationTime = (live && !(reply.includes("reply") || reply.includes("instant"))) ? 200 : 0
    // create bubble element
    var bubble = document.createElement("div")
    var bubbleContent = document.createElement("span")
    bubble.className = "bubble imagine " + (!live ? " history " : "") + reply
    bubbleContent.className = "bubble-content"
    
    // Process markdown and handle newlines
    let processedContent = say;
    
    // First, preserve whitespace in ALL content by pre-processing
    // Convert multiple consecutive newlines to spacing markers
    const originalContent = say;
    const hasMultipleBlankLines = /\n\s*\n\s*\n/.test(originalContent);
    
    // Check if marked is available and content looks like markdown
    if (typeof marked !== 'undefined' && (say.includes('#') || say.includes('**') || say.includes('*') || say.includes('-') || say.includes('```'))) {
      try {
        processedContent = marked.parse(say);
        
        // Handle whitespace preservation for markdown
        if (hasMultipleBlankLines) {
          // Add extra spacing between paragraphs and other block elements where there were multiple blank lines
          processedContent = processedContent
            .replace(/<\/p>\s*\n\s*<p>/g, '</p><div style="height: 0.75em;"></div><p>')
            .replace(/<\/h[1-6]>\s*\n\s*<p>/g, (match) => match.replace(/\n/, '\n<div style="height: 0.75em;"></div>'))
            .replace(/<\/p>\s*\n\s*<h[1-6]>/g, (match) => match.replace(/\n/, '\n<div style="height: 0.75em;"></div>'))
            .replace(/<\/h[1-6]>\s*\n\s*<h[1-6]>/g, (match) => match.replace(/\n/, '\n<div style="height: 0.75em;"></div>'));
        }
      } catch (error) {
        console.warn('Failed to parse markdown, falling back to text:', error);
        // Fall back to enhanced newline handling with blank line preservation
        processedContent = say
          .replace(/\n\n+/g, '\n<div style="height: 0.75em;"></div>\n') // Preserve blank lines
          .replace(/\n/g, '<br>');
      }
    } else {
      // Enhanced newline to <br> conversion with blank line preservation
      processedContent = say
        .replace(/\n\n+/g, '\n<div style="height: 0.75em;"></div>\n') // Preserve blank lines 
        .replace(/\n/g, '<br>');
    }
    
    bubbleContent.innerHTML = processedContent
    bubble.appendChild(bubbleContent)
    bubbleWrap.insertBefore(bubble, bubbleTyping)
    // answer picker styles
    if (reply !== "") {
      var bubbleButtons = bubbleContent.querySelectorAll(".bubble-button")
      for (var z = 0; z < bubbleButtons.length; z++) {
        ;(function(el) {
          if (!el.parentNode.parentNode.classList.contains("reply-freeform"))
            el.style.width = el.offsetWidth - sidePadding * 2 + widerBy + "px"
        })(bubbleButtons[z])
      }
      bubble.addEventListener("click", function(e) {
        if (e.target.classList.contains('bubble-button')) {
          for (var i = 0; i < bubbleButtons.length; i++) {
            ;(function(el) {
              el.style.width = 0 + "px"
              el.classList.contains("bubble-pick") ? (el.style.width = "") : false
              el.removeAttribute("onclick")
            })(bubbleButtons[i])
          }
          this.classList.add("bubble-picked")
        }
      })
    }
    // time, size & animate
    wait = live ? localAnimationTime * 2 : 0
    live && setTimeout(function() {
      bubbleTyping.classList.add("imagine")
    }, wait - localAnimationTime * 2)
    bubbleQueue = setTimeout(function() {
      bubble.classList.remove("imagine")
      
      bubble.classList.add("say")
      
      // Use responsive width instead of content-based width
      if (reply == "") {
        if (say.includes("<img src=")) {
          bubble.style.width = "50%"
        } else {
          // Make bubbles fill most of the available width for better readability
          bubble.style.width = "calc(100% - 24px)" // Leave some margin
          bubble.style.maxWidth = "none" // Remove any max-width restrictions
        }
      }
      posted()

      // save the interaction
      interactionsSave(say, reply)
      !iceBreaker && interactionsSaveCommit() // save point

      // animate scrolling
      containerHeight = container.offsetHeight
      scrollDifference = bubbleWrap.scrollHeight - bubbleWrap.scrollTop
      scrollHop = scrollDifference / 200
      var scrollBubbles = function() {
        for (var i = 1; i <= scrollDifference / scrollHop; i++) {
          ;(function() {
            setTimeout(function() {
              bubbleWrap.scrollHeight - bubbleWrap.scrollTop > containerHeight
                ? (bubbleWrap.scrollTop = bubbleWrap.scrollTop + scrollHop)
                : false
            }, i * 5)
          })()
        }
      }
      setTimeout(scrollBubbles, localAnimationTime / 2)
    }, wait + localAnimationTime * 2)
  }

  // recall previous interactions
  for (var i = 0; i < interactionsHistory.length; i++) {
    addBubble(
      interactionsHistory[i].say,
      function() {},
      interactionsHistory[i].reply,
      false
    )
  }
}

// below functions are specifically for WebPack-type project that work with import()

// this function automatically adds all HTML and CSS necessary for chat-bubble to function
function prepHTML(options) {
  // options
  var options = typeof options !== "undefined" ? options : {}
  var container = options.container || "chat" // id of the container HTML element
  var relative_path = options.relative_path || "./node_modules/chat-bubble/"

  // make HTML container element
  window[container] = document.createElement("div")
  window[container].setAttribute("id", container)
  document.body.appendChild(window[container])

  // style everything
  var appendCSS = function(file) {
    var link = document.createElement("link")
    link.href = file
    link.type = "text/css"
    link.rel = "stylesheet"
    link.media = "screen,print"
    document.getElementsByTagName("head")[0].appendChild(link)
  }
  appendCSS(relative_path + "component/styles/input.css")
  appendCSS(relative_path + "component/styles/reply.css")
  appendCSS(relative_path + "component/styles/says.css")
  appendCSS(relative_path + "component/styles/setup.css")
  appendCSS(relative_path + "component/styles/typing.css")
}

// exports for es6
if (typeof exports !== "undefined") {
  exports.Bubbles = Bubbles
  exports.prepHTML = prepHTML
}
