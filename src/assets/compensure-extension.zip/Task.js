// ABOUTME: Task class mirroring Python Task dataclass
// ABOUTME: Represents a processing task with type, status, messages and metadata

class Task {
    constructor(
        id,
        taskType,
        name,
        instructions,
        inputFiles,
        outputFile,
        status,
        createdAt,
        updatedAt,
        messages = [],
        sessionId = null,
        result = null,
        conversationId = null
    ) {
        this.id = id;
        this.task_type = taskType;
        this.name = name;
        this.instructions = instructions;
        this.input_files = inputFiles;
        this.output_file = outputFile;
        this.status = status; // 'queued', 'running', 'completed', 'failed'
        this.created_at = createdAt;
        this.updated_at = updatedAt;
        this.messages = messages; // Array of Message objects
        this.session_id = sessionId;
        this.result = result;
        this.conversation_id = conversationId;
    }

    static fromJSON(json) {
        // Convert messages to Message objects if they exist and Message is available
        let messages = [];
        if (json.messages && Array.isArray(json.messages)) {
            messages = json.messages.map(msg => {
                if (typeof Message !== 'undefined') {
                    return Message.fromJSON(msg);
                }
                return msg;
            });
        }

        return new Task(
            json.id,
            json.task_type,
            json.name,
            json.instructions,
            json.input_files || [],
            json.output_file || null,
            json.status,
            json.created_at,
            json.updated_at,
            messages,
            json.session_id || null,
            json.result || null,
            json.conversation_id || null
        );
    }

    toJSON() {
        return {
            id: this.id,
            task_type: this.task_type,
            name: this.name,
            instructions: this.instructions,
            input_files: this.input_files,
            output_file: this.output_file,
            status: this.status,
            created_at: this.created_at,
            updated_at: this.updated_at,
            messages: this.messages.map(msg => 
                msg.toJSON ? msg.toJSON() : msg
            ),
            session_id: this.session_id,
            result: this.result,
            conversation_id: this.conversation_id
        };
    }

    isComplete() {
        return this.status === 'completed' || this.status === 'failed';
    }

    isRunning() {
        return this.status === 'running';
    }
}

// Export for both Node.js (testing) and browser
if (typeof module !== 'undefined' && module.exports) {
    module.exports = Task;
} else {
    window.Task = Task;
}