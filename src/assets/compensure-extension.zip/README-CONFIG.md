# CompenSure Extension Configuration

## Changing the Server URL

To configure the extension to connect to a different server, edit the `config.js` file:

### Default Configuration
```javascript
const COMPENSURE_CONFIG = {
    SERVER_URL: 'http://localhost:8000',
    // ... other settings
};
```

### Examples

#### Different Port
```javascript
const COMPENSURE_CONFIG = {
    SERVER_URL: 'http://localhost:3000',
    // ... other settings
};
```

#### Remote Server
```javascript
const COMPENSURE_CONFIG = {
    SERVER_URL: 'https://compensure-server.example.com',
    // ... other settings
};
```

#### Different Host
```javascript
const COMPENSURE_CONFIG = {
    SERVER_URL: 'http://192.168.1.100:8000',
    // ... other settings
};
```

### Permissions

If you change the server URL to a non-localhost address, you may need to update the `host_permissions` in `manifest.json`:

```json
{
  "host_permissions": [
    "http://localhost:*/*", 
    "https://localhost:*/*", 
    "http://192.168.1.*:*/*",
    "https://your-domain.com/*"
  ]
}
```

### Additional Configuration

You can also modify other settings in the config:

- `TASK_POLL_INTERVAL`: How often to poll for task updates (milliseconds)
- `UI.MAX_RETRIES`: Maximum number of retry attempts
- `UI.TIMEOUT`: Request timeout in milliseconds

### Notes

- After changing the configuration, reload the extension in Chrome
- The extension will automatically use the new server URL for all API calls
- Make sure the server is running and accessible at the configured URL
- Check browser console for any connection errors if the server URL is incorrect