// ABOUTME: Conversation class mirroring Python Conversation dataclass
// ABOUTME: Central state management for chat conversations including messages and tasks

class Conversation {
    constructor(
        id,
        createdAt,
        updatedAt,
        status = 'active',
        messages = [],
        tasks = []
    ) {
        this.id = id;
        this.created_at = createdAt;
        this.updated_at = updatedAt;
        this.status = status; // 'active', 'archived'
        this.messages = messages; // Array of Message objects
        this.tasks = tasks; // Array of Task objects
        this.sentToBackend = false; // Track if conversation has been sent to backend
    }

    static fromJSON(json) {
        // Convert messages to Message objects if available
        let messages = [];
        if (json.messages && Array.isArray(json.messages)) {
            messages = json.messages.map(msg => {
                if (typeof Message !== 'undefined') {
                    return Message.fromJSON(msg);
                }
                return msg;
            });
        }

        // Convert tasks to Task objects if available
        let tasks = [];
        if (json.tasks && Array.isArray(json.tasks)) {
            tasks = json.tasks.map(task => {
                if (typeof Task !== 'undefined') {
                    return Task.fromJSON(task);
                }
                return task;
            });
        }

        const conversation = new Conversation(
            json.id,
            json.created_at,
            json.updated_at,
            json.status || 'active',
            messages,
            tasks
        );
        
        // If conversation came from server, it was sent to backend
        conversation.sentToBackend = true;
        
        return conversation;
    }

    toJSON() {
        return {
            id: this.id,
            created_at: this.created_at,
            updated_at: this.updated_at,
            status: this.status,
            messages: this.messages.map(msg => 
                msg.toJSON ? msg.toJSON() : msg
            ),
            tasks: this.tasks.map(task => 
                task.toJSON ? task.toJSON() : task
            )
        };
    }

    // Helper methods for managing conversation state
    addMessage(message) {
        this.messages.push(message);
        this.updated_at = new Date().toISOString();
    }

    addTask(task) {
        this.tasks.push(task);
        this.updated_at = new Date().toISOString();
    }

    getTaskById(taskId) {
        return this.tasks.find(task => task.id === taskId);
    }

    getCurrentTask() {
        // Get the most recent task that's not completed
        for (let i = this.tasks.length - 1; i >= 0; i--) {
            const task = this.tasks[i];
            if (!task.isComplete()) {
                return task;
            }
        }
        return null;
    }

    updateTask(taskId, updates) {
        const task = this.getTaskById(taskId);
        if (task) {
            Object.assign(task, updates);
            this.updated_at = new Date().toISOString();
        }
        return task;
    }

    // Update entire conversation from server response
    updateFromJSON(json) {
        if (json.id) this.id = json.id;
        if (json.created_at) this.created_at = json.created_at;
        if (json.updated_at) this.updated_at = json.updated_at;
        if (json.status) this.status = json.status;
        
        // Update messages
        if (json.messages && Array.isArray(json.messages)) {
            this.messages = json.messages.map(msg => {
                if (typeof Message !== 'undefined') {
                    return Message.fromJSON(msg);
                }
                return msg;
            });
        }
        
        // Update tasks
        if (json.tasks && Array.isArray(json.tasks)) {
            this.tasks = json.tasks.map(task => {
                if (typeof Task !== 'undefined') {
                    return Task.fromJSON(task);
                }
                return task;
            });
        }
    }

    clear() {
        // Reset everything to initial state with a new conversation ID
        const now = new Date().toISOString();
        this.id = this.generateUUID();
        this.created_at = now;
        this.updated_at = now;
        this.status = 'active';
        this.messages = [];
        this.tasks = [];
        this.sentToBackend = false;
    }

    generateUUID() {
        // Simple UUID v4 generator for client-side use
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
            const r = Math.random() * 16 | 0;
            const v = c === 'x' ? r : (r & 0x3 | 0x8);
            return v.toString(16);
        });
    }
}

// Export for both Node.js (testing) and browser
if (typeof module !== 'undefined' && module.exports) {
    module.exports = Conversation;
} else {
    window.Conversation = Conversation;
}