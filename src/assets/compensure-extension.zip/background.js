// ABOUTME: Service worker for Chrome extension with state management
// ABOUTME: Handles panel toggling, state persistence, and message routing

// Import config at the top level for service workers
self.importScripts('config.js');

// State management constants
const STATE_KEY = 'appState';
const STAGES = {
  LOGIN: 'login',
  INITIALIZE: 'initialize',
  CHAT: 'chat'
};

// State transition rules enforcement
// Rules:
// - Any stage can go to login
// - Login can only go to initialize
// - Initialize can go to any stage
// - Chat can go to any stage
function validateStateTransition(fromStage, toStage) {
  // Any stage can always go to login
  if (toStage === STAGES.LOGIN) {
    return true;
  }
  
  // Check specific rules based on current stage
  switch (fromStage) {
    case STAGES.LOGIN:
      // Login can only go to initialize (or back to login)
      return toStage === STAGES.INITIALIZE;
      
    case STAGES.INITIALIZE:
      // Initialize can go to any stage
      return true;
      
    case STAGES.CHAT:
      // Chat can go to any stage
      return true;
      
    default:
      // Unknown stage - only allow login
      return toStage === STAGES.LOGIN;
  }
}

// Get current application state
async function getCurrentState() {
  try {
    const result = await chrome.storage.local.get(STATE_KEY);
    return result[STATE_KEY] || { stage: STAGES.LOGIN, timestamp: Date.now() };
  } catch (error) {
    console.error('Error getting app state:', error);
    return { stage: STAGES.LOGIN, timestamp: Date.now() };
  }
}

// Update application state with validation
async function updateState(newState) {
  try {
    // Get current state to validate transition
    const currentState = await getCurrentState();
    const fromStage = currentState.stage;
    const toStage = newState.stage;
    
    // Validate the state transition
    if (!validateStateTransition(fromStage, toStage)) {
      console.error(`Invalid state transition: ${fromStage} -> ${toStage}`);
      return { 
        success: false, 
        error: `Cannot transition from ${fromStage} to ${toStage}` 
      };
    }
    
    // Valid transition - save the new state
    await chrome.storage.local.set({ [STATE_KEY]: newState });
    console.log(`State transition: ${fromStage} -> ${toStage}`);
    return { success: true };
  } catch (error) {
    console.error('Error updating app state:', error);
    return { 
      success: false, 
      error: error.message 
    };
  }
}

// Reset to login state (always allowed)
async function resetToLogin() {
  const result = await updateState({ stage: STAGES.LOGIN, timestamp: Date.now() });
  return result.success;
}

chrome.action.onClicked.addListener((tab) => {
  // Toggle the panel open/closed when extension icon is clicked
  chrome.sidePanel.open({ windowId: tab.windowId });
});

// Handle extension startup/reload - end any active conversations
chrome.runtime.onStartup.addListener(() => {
  endConversationOnServer();
});

chrome.runtime.onInstalled.addListener(() => {
  endConversationOnServer();
});

// Note: Extension restart no longer ends conversations since we need specific conversation IDs
// Conversations are now managed per-conversation and the backend no longer tracks "active" conversations
async function endConversationOnServer() {
  console.log('Extension restart detected - individual conversations are now managed by conversation ID');
  // No longer ending conversations on extension restart since we need specific conversation IDs
  // and there's no global "active conversation" concept anymore
}

// Listen for state management messages from content scripts
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'getState') {
    getCurrentState().then(sendResponse);
    return true; // Will respond asynchronously
  } else if (request.action === 'updateState') {
    // updateState now returns an object with success/error
    updateState(request.state).then(sendResponse);
    return true; // Will respond asynchronously
  } else if (request.action === 'resetToLogin') {
    resetToLogin().then(success => sendResponse({ success }));
    return true; // Will respond asynchronously
  }
});