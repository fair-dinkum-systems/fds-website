// ABOUTME: JavaScript for initializing and controlling the chat interface in the Chrome extension
// ABOUTME: Uses ChatController for state management, DOM manipulation and polling coordination

document.addEventListener('DOMContentLoaded', async function() {
    // Wait for the sidepanel to become visible before initializing
    if (document.hidden) {
        document.addEventListener('visibilitychange', initializeSidepanel, { once: true });
    } else {
        initializeSidepanel();
    }
});


async function initializeSidepanel() {
    // Initialize storage persistence
    const storage = new StoragePersistence();

    // Initialize auth (similar to initialize.js)
    const auth = new OneDriveAuth();

    const workerManager = new WorkerManager(auth);
    await workerManager.initialize();

    // Wait for worker to be ready before proceeding with initialization
    if (!workerManager.isWorkerReady()) {
        console.log('Worker not ready yet, waiting...');
        await new Promise(resolve => {
            workerManager.onWorkerReady(resolve);
        });
        console.log('Worker is now ready');
    }

    // Set API credentials after worker is ready
    api.setWorkerUrl(workerManager.getWorkerUrl());
    api.setWorkerToken(workerManager.getWorkerToken());

    // Initialize controller - worker is guaranteed to be ready
    const controller = new ChatController(storage, workerManager);
    await controller.init();
    
    // Initialize sync status manager with API and pass workerManager reference
    let syncStatusManager = null;
    try {
        syncStatusManager = new SyncStatusManager(api);
        syncStatusManager.workerManager = workerManager; // Add workerManager reference
        syncStatusManager.init();
        
        // Start sync status polling when worker is ready
        syncStatusManager.waitForWorkerAndStart();
    } catch (error) {
        console.error('Failed to initialize SyncStatusManager:', error);
        // Continue without sync status manager - don't break the whole app
    }

    // Make all globally accessible for debugging
    window.storagePersistence = storage;
    window.chatController = controller;
    window.syncStatusManager = syncStatusManager;

    const logoutBtn = document.getElementById('logout-btn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', async function() {
            try {
                // Chat can go to any stage - going back to login
                await chrome.storage.local.set({
                    appState: {
                        stage: 'login',
                        timestamp: Date.now()
                    }
                });
                
                // Navigate to login screen
                window.location.replace('login.html');
            } catch (error) {
                console.error('Error during logout:', error);
                alert('Logout failed. Please try again.');
            }
        });
    }

    // Add cleanup on page unload (extension refresh/close)
    // Use sendBeacon for reliable delivery during page unload
    window.addEventListener('beforeunload', () => {
        if (syncStatusManager) {
            syncStatusManager.destroy();
        }
    });

    // Also try with unload as fallback
    window.addEventListener('unload', () => {
        if (syncStatusManager) {
            syncStatusManager.destroy();
        }
    });

    // Initialize the chat bubble with input enabled
    const chatWindow = new Bubbles(
        document.getElementById("chat"),
        "chatWindow",
        {
            inputCallbackFn: function(obj) {
                // Handle user input
                console.log("User input:", obj.input);
                
                // Check for /clear command
                if (obj.input.trim() === '/clear' || obj.input.trim() === '/cl') {
                    // Call async clearConversation method
                    controller.clearConversation().catch(error => {
                        console.error('Error clearing conversation:', error);
                    });
                    return obj.input;
                }
                
                // Submit task to server via controller
                controller.handleUserInput(obj.input);
                
                return obj.input;
            }
        }
    );

    // Set the chat window reference in controller
    controller.setChatWindow(chatWindow);

    // Initialize chat without automatic message - just enable input
    // The chat will start empty and wait for user input
}