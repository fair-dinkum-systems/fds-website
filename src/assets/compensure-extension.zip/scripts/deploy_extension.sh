#!/bin/bash
# ABOUTME: Chrome extension deployment script with private key packing
# ABOUTME: Creates stable extension ID using private key to ensure consistent OAuth redirect URIs

set -e  # Exit on any error

# Configuration
EXTENSION_DIR="$(dirname "$0")/.."
PRIVATE_KEY="$EXTENSION_DIR/../extension_private_key.pem"
OUTPUT_DIR="$EXTENSION_DIR/dist"
EXTENSION_NAME="CompenSure"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}🚀 Chrome Extension Deployment Script${NC}"
echo "=================================="

# Create output directory
mkdir -p "$OUTPUT_DIR"
echo -e "${GREEN}✅ Created output directory: $OUTPUT_DIR${NC}"

# Check if Chrome is available for packing
CHROME_BINARY=""
if command -v google-chrome &> /dev/null; then
    CHROME_BINARY="google-chrome"
elif command -v chromium &> /dev/null; then
    CHROME_BINARY="chromium"
elif command -v chrome &> /dev/null; then
    CHROME_BINARY="chrome"
elif [ -f "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" ]; then
    CHROME_BINARY="/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
else
    echo -e "${RED}❌ Chrome/Chromium not found${NC}"
    echo "Please install Chrome or Chromium to pack the extension."
    exit 1
fi

echo -e "${GREEN}✅ Found Chrome binary: $CHROME_BINARY${NC}"

# Pack the extension
echo -e "${YELLOW}📦 Packing extension...${NC}"

if [ -f "$PRIVATE_KEY" ]; then
    echo -e "${GREEN}✅ Using existing private key${NC}"
    "$CHROME_BINARY" --pack-extension="$EXTENSION_DIR" --pack-extension-key="$PRIVATE_KEY" --no-message-box >/dev/null 2>&1
else
    echo -e "${YELLOW}⚠️  Generating new private key${NC}"
    "$CHROME_BINARY" --pack-extension="$EXTENSION_DIR" --no-message-box >/dev/null 2>&1
    
    # Move generated key to expected location
    if [ -f "$EXTENSION_DIR.pem" ]; then
        mv "$EXTENSION_DIR.pem" "$PRIVATE_KEY"
        echo -e "${GREEN}✅ Generated new private key${NC}"
        
        # Extract public key and update manifest
        echo -e "${YELLOW}📝 Updating manifest with public key...${NC}"
        PUBLIC_KEY=$(openssl rsa -in "$PRIVATE_KEY" -pubout -outform DER 2>/dev/null | openssl base64 -A)
        
        if [ ! -z "$PUBLIC_KEY" ]; then
            # Update manifest with key
            node -e "
const fs = require('fs');
const manifest = JSON.parse(fs.readFileSync('$EXTENSION_DIR/manifest.json', 'utf8'));
manifest.key = '$PUBLIC_KEY';
fs.writeFileSync('$EXTENSION_DIR/manifest.json', JSON.stringify(manifest, null, 2));
"
            echo -e "${GREEN}✅ Updated manifest with public key${NC}"
        fi
    fi
fi

# Check if packing succeeded
if [ -f "$EXTENSION_DIR.crx" ]; then
    mv "$EXTENSION_DIR.crx" "$OUTPUT_DIR/${EXTENSION_NAME}.crx"
    echo -e "${GREEN}✅ Extension packed successfully${NC}"
else
    echo -e "${RED}❌ Extension packing failed${NC}"
    exit 1
fi

# Calculate final extension ID
EXTENSION_ID=$(node -e "
const crypto = require('crypto');
const fs = require('fs');
const manifest = JSON.parse(fs.readFileSync('$EXTENSION_DIR/manifest.json', 'utf8'));
if (manifest.key) {
    const hash = crypto.createHash('sha256').update(Buffer.from(manifest.key, 'base64')).digest();
    const extensionId = Array.from(hash.slice(0, 16)).map(b => String.fromCharCode(97 + (b % 26))).join('');
    console.log(extensionId);
} else {
    console.log('unknown');
}
" 2>/dev/null)

# Get file size
FILE_SIZE=$(ls -lh "$OUTPUT_DIR/${EXTENSION_NAME}.crx" | awk '{print $5}')

echo ""
echo -e "${GREEN}🎉 Deployment Complete!${NC}"
echo "=================================="
echo -e "${BLUE}📁 Files created:${NC}"
echo "   📦 $OUTPUT_DIR/${EXTENSION_NAME}.crx (${FILE_SIZE})"
echo "   🔑 $PRIVATE_KEY"
echo ""
echo -e "${BLUE}🔧 Installation:${NC}"
echo "   1. Go to chrome://extensions/"
echo "   2. Enable 'Developer mode'"
echo "   3. Drag and drop ${EXTENSION_NAME}.crx to install"
echo "   4. Extension ID will be: $EXTENSION_ID"
echo ""
echo -e "${BLUE}🌐 OAuth Setup:${NC}"
echo "   Use this redirect URI in Azure: https://$EXTENSION_ID.chromiumapp.org/"
echo ""
echo -e "${YELLOW}⚠️  Security Note:${NC}"
echo "   Keep $PRIVATE_KEY secure and never commit it to version control!"