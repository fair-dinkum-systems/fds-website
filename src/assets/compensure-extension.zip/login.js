// ABOUTME: Handles login screen logic and OneDrive authentication
// ABOUTME: Manages Microsoft OAuth flow and navigation to initialize stage

document.addEventListener('DOMContentLoaded', function() {
    const loginBtn = document.getElementById('loginBtn');
    
    // Load config first, then OneDrive authentication module
    const configScript = document.createElement('script');
    configScript.src = 'config.js';
    document.head.appendChild(configScript);
    
    configScript.onload = function() {
        const authScript = document.createElement('script');
        authScript.src = 'auth/OneDriveAuth.js';
        document.head.appendChild(authScript);
        
        authScript.onload = setupLoginFlow;
    };
    
    function setupLoginFlow() {
        const auth = new OneDriveAuth();
        
        // Check if already authenticated
        checkAuthStatus();
        
        async function checkAuthStatus() {
            try {
                const isAuth = await auth.isAuthenticated();
                if (isAuth) {
                    // Already authenticated, go to initialize
                    await chrome.storage.local.set({
                        appState: {
                            stage: 'initialize',
                            timestamp: Date.now()
                        }
                    });
                    window.location.replace('initialize.html');
                } else {
                    // Update button text to be more specific
                    loginBtn.textContent = 'Connect OneDrive';
                }
            } catch (error) {
                console.error('Error checking auth status:', error);
            }
        }
        
        loginBtn.addEventListener('click', async function() {
            try {
                // Disable button during authentication
                loginBtn.disabled = true;
                loginBtn.textContent = 'Connecting...';
                
                // Authenticate with Microsoft/OneDrive
                const result = await auth.authenticate();
                
                if (result && result.user) {
                    // Store user info and transition to initialize stage
                    await chrome.storage.local.set({
                        appState: {
                            stage: 'initialize',
                            timestamp: Date.now(),
                            user: {
                                displayName: result.user.displayName,
                                email: result.user.mail || result.user.userPrincipalName,
                                id: result.user.id
                            }
                        }
                    });
                    
                    // Navigate to initialize screen for folder selection
                    window.location.replace('initialize.html');
                }
            } catch (error) {
                console.error('Error during OneDrive authentication:', error);
                
                // Re-enable button
                loginBtn.disabled = false;
                loginBtn.textContent = 'Connect OneDrive';
                
                // Show user-friendly error message
                let errorMessage = 'Authentication failed. ';
                if (error.message) {
                    if (error.message.includes('User cancelled')) {
                        errorMessage += 'Sign-in was cancelled.';
                    } else if (error.message.includes('Network')) {
                        errorMessage += 'Please check your internet connection.';
                    } else {
                        errorMessage += error.message;
                    }
                } else {
                    errorMessage += 'Please try again.';
                }
                
                alert(errorMessage);
            }
        });
    }
});