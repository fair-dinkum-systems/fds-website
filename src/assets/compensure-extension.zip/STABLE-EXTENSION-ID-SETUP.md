# Stable Chrome Extension ID Setup

This guide explains how to ensure your Chrome extension always has the same ID, which fixes Microsoft OAuth redirect URI issues.

## Problem
Chrome extensions normally get random IDs that change between installations, causing Microsoft OAuth redirect URIs like `https://[random-id].chromiumapp.org/` to stop working.

## Solution
Add a `key` field to `manifest.json` containing an RSA public key. This ensures the extension ID is deterministically generated from the key.

## Current Setup

Your extension now has a stable ID: **`rkzfptwtmvrwhnmq`**

**Stable Redirect URI:** `https://rkzfptwtmvrwhnmq.chromiumapp.org/`

## Azure Configuration

Configure your Microsoft App Registration with this stable redirect URI:

1. Go to Azure Portal > App Registrations > Your App
2. Click "Authentication"
3. Remove any old redirect URIs
4. Add: `https://rkzfptwtmvrwhnmq.chromiumapp.org/`
5. Save changes

## How It Works

1. The `key` field in `manifest.json` contains an RSA public key
2. Chrome generates the extension ID by hashing this public key
3. Same key = same hash = same extension ID
4. Extension ID `rkzfptwtmvrwhnmq` will be consistent across all installations

## Security Notes

- ✅ **Keep private key secure**: The private key (`private_key.pem`) should be stored securely
- ✅ **Don't commit private key**: Never commit the private key to version control
- ✅ **Extension ID is stable**: Works in development and production
- ✅ **Same across users**: All users will get the same extension ID

## Files Modified

- `manifest.json`: Added `key` field with RSA public key
- `auth/OneDriveAuth.js`: Reverted to use `chrome.identity.getRedirectURL()`
- `config.js`: Removed custom REDIRECT_URI (uses Chrome's built-in redirect)

## Verification

To verify the stable ID:
1. Load the extension in Chrome
2. Check `chrome://extensions/` for the extension ID
3. Should always be: `rkzfptwtmvrwhnmq`
4. Console should log: "Stable Chrome Extension Redirect URI for Azure setup: https://rkzfptwtmvrwhnmq.chromiumapp.org/"

## Benefits

- ✅ **No more redirect URI changes** when extension ID changes
- ✅ **Works in development and production**
- ✅ **Consistent across all users and installations**
- ✅ **No external dependencies** (no need for external redirect servers)
- ✅ **Uses Chrome's built-in OAuth flow** (more secure and reliable)

## Custom Extension ID

If you need a specific extension ID (like `onbgldhbnhhjafhojlndepeieajjhcek`), you would need:
1. The original private key that generated that ID, OR
2. Computationally find a new key that produces that exact ID (very difficult)

For most cases, using the stable ID `rkzfptwtmvrwhnmq` is the best solution.