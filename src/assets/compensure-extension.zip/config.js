// ABOUTME: Global configuration for the CompenSure Chrome extension
// ABOUTME: Contains server URL and other configurable settings

/**
 * Global configuration object for the CompenSure extension.
 * 
 * Worker manager URL points to your deployed worker manager Lambda.
 * Workers are dynamically created and their URLs are stored in browser storage.
 * 
 * After changing, reload the extension in Chrome to apply changes.
 */
const COMPENSURE_CONFIG = {
    // Worker manager configuration - CHANGE THIS to point to your deployed worker manager
    WORKER_MANAGER_URL: 'https://6zndwrp3g6.execute-api.ap-southeast-2.amazonaws.com/dev',
    
    // API endpoints (relative to worker URL)
    ENDPOINTS: {
        NEW_MESSAGE: '/conversations/new-message',
        STATUS: '/status',
        CONVERSATIONS: '/conversations', 
        END_CONVERSATION: '/end-conversation',
        SYNC_STATUS: '/sync/status',
        SYNC_PULL: '/sync/pull',
        SYNC_PUSH: '/sync/push'
    },
    
    // Polling intervals
    TASK_POLL_INTERVAL: 2000, // 2 seconds
    
    // UI configuration
    UI: {
        MAX_RETRIES: 3,
        TIMEOUT: 120000 // 2 minutes
    },
    
    // Microsoft OneDrive OAuth configuration
    MICROSOFT: {
        // TODO: Replace with your actual Client ID from Azure App Registration
        CLIENT_ID: 'e0499238-9c79-4134-90b8-c7929fa05ba6',
        
        // Tenant should remain 'common' to allow any Microsoft account
        TENANT: 'common',
        
        // OAuth scopes needed for OneDrive access
        SCOPES: [
            'Files.Read',
            'Files.Read.All',
            'Files.ReadWrite',
            'Files.ReadWrite.All', 
            'Sites.Read.All',
            'Sites.ReadWrite.All',
            'User.Read',
            'offline_access'
        ],
        
        // Microsoft Graph API base URL
        GRAPH_API_URL: 'https://graph.microsoft.com/v1.0'
    }
};

// Helper function to get worker manager URL
function getWorkerManagerURL() {
    return COMPENSURE_CONFIG.WORKER_MANAGER_URL;
}

// Make config globally available
if (typeof window !== 'undefined') {
    window.COMPENSURE_CONFIG = COMPENSURE_CONFIG;
    window.getWorkerManagerURL = getWorkerManagerURL;
}

// Export for Node.js testing environments
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        COMPENSURE_CONFIG,
        getWorkerManagerURL
    };
}