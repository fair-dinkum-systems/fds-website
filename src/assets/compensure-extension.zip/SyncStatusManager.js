// ABOUTME: Sync status manager for polling and displaying workspace sync status
// ABOUTME: Handles real-time sync status updates and UI display in the status bar

class SyncStatusManager {
    constructor(api) {
        this.api = api;
        this.pollInterval = null;
        this.currentStatus = null;
        this.statusBar = null;
        this.statusText = null;
        
        // Status display mapping
        this.statusMessages = {
            'synced': 'Sync Status: Synced',
            'stale': 'Sync Status: Stale',
            'pushing': 'Sync Status: Pushing...',
            'pulling': 'Sync Status: Pulling...',
            'pull_failed': 'Sync Status: Pull Failed',
            'push_failed': 'Sync Status: Push Failed',
            'both_failed': 'Sync Status: Both Failed'
        };
    }

    init() {
        this.statusBar = document.getElementById('sync-status-bar');
        this.statusText = document.getElementById('sync-status-text');
        this.pullTrigger = document.getElementById('sync-pull-trigger');
        this.pushTrigger = document.getElementById('sync-push-trigger');
        this.logoutBtn = document.getElementById('logout-btn');
        
        if (!this.statusBar || !this.statusText) {
            console.warn('Sync status UI elements not found - sync functionality will be disabled');
            return;
        }

        // Set up pull trigger click handler
        if (this.pullTrigger) {
            this.pullTrigger.addEventListener('click', () => this.handlePullClick());
        }

        // Set up push trigger click handler
        if (this.pushTrigger) {
            this.pushTrigger.addEventListener('click', () => this.handlePushClick());
        }

        // Don't start polling immediately - let sidepanel.js call startPolling when worker is ready
        console.log('SyncStatusManager initialized but not polling yet - waiting for worker');
    }

    waitForWorkerAndStart() {
        try {
            // Check if worker is ready
            if (this.workerManager && this.workerManager.isWorkerReady()) {
                console.log('Worker is ready, starting sync status polling');
                this.startPolling();
            } else {
                console.log('Worker not ready yet, will retry in 2 seconds');
                setTimeout(() => this.waitForWorkerAndStart(), 2000);
            }
        } catch (error) {
            console.error('Error in waitForWorkerAndStart:', error);
            // Retry anyway in case it's a temporary issue
            setTimeout(() => this.waitForWorkerAndStart(), 5000);
        }
    }

    startPolling() {
        // Poll immediately first
        this.pollSyncStatus();
        
        // Then set up regular polling every 3 seconds
        if (this.pollInterval) {
            clearInterval(this.pollInterval);
        }
        
        this.pollInterval = setInterval(() => {
            this.pollSyncStatus();
        }, 3000);
        
        console.log('Sync status polling started');
    }

    stopPolling() {
        if (this.pollInterval) {
            clearInterval(this.pollInterval);
            this.pollInterval = null;
        }
        console.log('Sync status polling stopped');
    }

    // Helper method to disable all triggers during sync operations
    disableAllTriggers() {
        const triggers = [this.pullTrigger, this.pushTrigger, this.logoutBtn];
        
        triggers.forEach(trigger => {
            if (trigger) {
                trigger.style.pointerEvents = 'none';
                trigger.style.opacity = '0.5';
            }
        });
    }

    // Helper method to re-enable all triggers after sync operations
    enableAllTriggers() {
        const triggers = [this.pullTrigger, this.pushTrigger, this.logoutBtn];
        
        triggers.forEach(trigger => {
            if (trigger) {
                trigger.style.pointerEvents = '';
                trigger.style.opacity = '';
            }
        });
    }

    async pollSyncStatus() {
        try {
            const result = await this.api.getSyncStatus();
            if (result.success && result.data && result.data.sync_status) {
                this.updateSyncStatus(result.data.sync_status);
            }
        } catch (error) {
            console.error('Failed to poll sync status:', error);
            // Show error state but don't spam logs
            this.updateSyncStatus('error');
        }
    }

    async handlePullClick() {
        console.log('Pull trigger clicked');
        
        // Disable all triggers while processing
        this.disableAllTriggers();
        
        try {
            // Trigger the pull
            const result = await this.api.triggerSyncPull();
            
            if (result.success) {
                console.log('Pull triggered successfully:', result.data);
                
                // Immediately poll for status update
                await this.pollSyncStatus();
            } else {
                console.error('Failed to trigger pull');
            }
        } catch (error) {
            console.error('Error triggering pull:', error);
        } finally {
            // Re-enable all triggers after a short delay
            setTimeout(() => {
                this.enableAllTriggers();
            }, 2000);
        }
    }

    async handlePushClick() {
        console.log('Push trigger clicked');
        
        // Disable all triggers while processing
        this.disableAllTriggers();
        
        try {
            // Trigger the push
            const result = await this.api.triggerSyncPush();
            
            if (result.success) {
                console.log('Push triggered successfully:', result.data);
                
                // Immediately poll for status update
                await this.pollSyncStatus();
            } else {
                console.error('Failed to trigger push');
            }
        } catch (error) {
            console.error('Error triggering push:', error);
        } finally {
            // Re-enable all triggers after a short delay
            setTimeout(() => {
                this.enableAllTriggers();
            }, 2000);
        }
    }

    updateSyncStatus(status) {
        if (this.currentStatus === status) {
            return; // No change, skip update
        }

        this.currentStatus = status;

        if (!this.statusBar || !this.statusText) {
            return;
        }

        // Update status bar data attribute for styling
        this.statusBar.setAttribute('data-status', status);

        // Update text content
        const message = this.statusMessages[status] || `Sync Status: ${status}`;
        this.statusText.textContent = message;

        console.log(`Sync status updated to: ${status}`);
    }

    // Cleanup method
    destroy() {
        this.stopPolling();
        
        // Remove event listeners if they exist
        if (this.pullTrigger) {
            this.pullTrigger.removeEventListener('click', () => this.handlePullClick());
        }
        
        if (this.pushTrigger) {
            this.pushTrigger.removeEventListener('click', () => this.handlePushClick());
        }
        
        this.statusBar = null;
        this.statusText = null;
        this.pullTrigger = null;
        this.pushTrigger = null;
        this.logoutBtn = null;
    }
}

// Export for both Node.js (testing) and browser
if (typeof module !== 'undefined' && module.exports) {
    module.exports = SyncStatusManager;
} else {
    // Make available globally in browser
    window.SyncStatusManager = SyncStatusManager;
}