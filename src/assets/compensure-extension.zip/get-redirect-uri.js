// ABOUTME: Helper script to get Chrome extension redirect URI for OAuth setup
// ABOUTME: Run this in browser console to get the redirect URI for Azure registration

console.log('Chrome Extension Redirect URI:');
console.log(chrome.identity.getRedirectURL());
console.log('');
console.log('Copy this URI and paste it in Azure App Registration > Authentication > Redirect URIs');