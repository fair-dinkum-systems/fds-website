// ABOUTME: API service for communicating with the CompenSure server
// ABOUTME: Handles HTTP requests for conversations and task submissions

class CompenSureAPI {
    constructor() {
        this.workerUrl = null;
        this.workerToken = null;
    }

    setWorkerUrl(workerUrl) {
        this.workerUrl = workerUrl;
    }

    setWorkerToken(workerToken) {
        this.workerToken = workerToken;
    }

    getActiveURL() {
        if (!this.workerUrl) {
            throw new Error('No worker URL available. Worker must be initialized and active before making API calls.');
        }
        return this.workerUrl;
    }

    hasWorkerUrl() {
        return this.workerUrl !== null;
    }

    getAuthHeaders() {
        const headers = {
            'Content-Type': 'application/json'
        };
        
        if (this.workerToken) {
            headers['Authorization'] = `Bearer ${this.workerToken}`;
        }
        
        return headers;
    }

    async addMessage(taskText, conversationId) {
        try {
            if (!conversationId) {
                throw new Error('conversation_id is required for adding messages');
            }
            
            const requestBody = {
                message: taskText,
                conversation_id: conversationId
            };

            // Get sync credentials - required for sync operations
            const syncCredentials = await this.getSyncCredentials();
            requestBody.sync_credentials = syncCredentials;
            
            const response = await fetch(this.getActiveURL() + COMPENSURE_CONFIG.ENDPOINTS.NEW_MESSAGE, {
                method: 'POST',
                headers: this.getAuthHeaders(),
                body: JSON.stringify(requestBody)
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const result = await response.json();
            
            return { success: true, data: result };
        } catch (error) {
            console.error('Error submitting task:', error);
            throw error;
        }
    }

    async getTaskStatus(taskId) {
        try {
            console.log(`[API] Polling task status for ${taskId}`);
            const response = await fetch(this.getActiveURL() + COMPENSURE_CONFIG.ENDPOINTS.STATUS + `/${taskId}`, {
                method: 'GET',
                headers: this.getAuthHeaders()
            });

            if (!response.ok) {
                console.error(`[API] HTTP error getting task status: ${response.status}`);
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const result = await response.json();
            console.log(`[API] Task status response:`, result);
            return { success: true, data: result };
        } catch (error) {
            console.error('[API] Error getting task status:', error);
            throw error;
        }
    }

    async getConversation(conversationId) {
        if (!this.hasWorkerUrl()) {
            console.log('No worker URL available yet, skipping conversation load');
            return { success: false, data: null, reason: 'no_worker_url' };
        }
        
        try {
            const response = await fetch(this.getActiveURL() + COMPENSURE_CONFIG.ENDPOINTS.CONVERSATIONS + `/${conversationId}`, {
                method: 'GET',
                headers: this.getAuthHeaders()
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const result = await response.json();
            return { success: true, data: result };
        } catch (error) {
            console.error('Error getting conversation:', error);
            throw error;
        }
    }

    async listConversations() {
        try {
            const response = await fetch(this.getActiveURL() + COMPENSURE_CONFIG.ENDPOINTS.CONVERSATIONS, {
                method: 'GET',
                headers: this.getAuthHeaders()
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const result = await response.json();
            return { success: true, data: result };
        } catch (error) {
            console.error('Error listing conversations:', error);
            throw error;
        }
    }

    async addMessageToConversation(conversationId, message, messageType = 'user_message') {
        try {
            const response = await fetch(this.getActiveURL() + COMPENSURE_CONFIG.ENDPOINTS.CONVERSATIONS + `/${conversationId}/messages`, {
                method: 'POST',
                headers: this.getAuthHeaders(),
                body: JSON.stringify({
                    message: message,
                    type: messageType
                })
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const result = await response.json();
            return { success: true, data: result };
        } catch (error) {
            console.error('Error adding message to conversation:', error);
            throw error;
        }
    }

    async endConversation(conversationId) {
        try {
            if (!conversationId) {
                throw new Error('conversation_id is required for endConversation');
            }
            
            const requestBody = {
                conversation_id: conversationId
            };
            
            const response = await fetch(this.getActiveURL() + COMPENSURE_CONFIG.ENDPOINTS.END_CONVERSATION, {
                method: 'POST',
                headers: this.getAuthHeaders(),
                body: JSON.stringify(requestBody)
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const result = await response.json();
            
            return { success: true, data: result };
        } catch (error) {
            console.error('Error ending conversation:', error);
            throw error;
        }
    }

    async getSyncStatus() {
        try {
            const response = await fetch(this.getActiveURL() + COMPENSURE_CONFIG.ENDPOINTS.SYNC_STATUS, {
                method: 'GET',
                headers: this.getAuthHeaders()
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const result = await response.json();
            return { success: true, data: result };
        } catch (error) {
            console.error('Error getting sync status:', error);
            throw error;
        }
    }

    async getSyncCredentials() {
        try {
            // Get OneDrive access token
            const auth = new OneDriveAuth();
            const accessToken = await auth.getAccessToken();
            if (!accessToken) {
                throw new Error('No valid OneDrive access token available');
            }

            // Get selected folder
            const sync = new OneDriveSync(auth);
            const selectedFolder = await sync.getSelectedFolder();
            if (!selectedFolder) {
                throw new Error('No OneDrive folder selected for sync');
            }

            // Extract folder path from the selected folder
            let folderPath;
            if (selectedFolder.path && selectedFolder.path !== '/') {
                folderPath = selectedFolder.path + '/' + selectedFolder.name;
            } else {
                folderPath = '/' + selectedFolder.name;
            }

            return {
                access_token: accessToken,
                folder_path: folderPath
            };
        } catch (error) {
            console.error('Error getting sync credentials:', error);
            throw error;
        }
    }

    async triggerSyncPull() {
        try {
            // Get sync credentials
            const syncCredentials = await this.getSyncCredentials();
            
            const response = await fetch(this.getActiveURL() + COMPENSURE_CONFIG.ENDPOINTS.SYNC_PULL, {
                method: 'POST',
                headers: this.getAuthHeaders(),
                body: JSON.stringify({
                    sync_credentials: syncCredentials
                })
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const result = await response.json();
            return { success: true, data: result };
        } catch (error) {
            console.error('Error triggering sync pull:', error);
            throw error;
        }
    }

    async triggerSyncPush() {
        try {
            // Get sync credentials
            const syncCredentials = await this.getSyncCredentials();
            
            const response = await fetch(this.getActiveURL() + COMPENSURE_CONFIG.ENDPOINTS.SYNC_PUSH, {
                method: 'POST',
                headers: this.getAuthHeaders(),
                body: JSON.stringify({
                    sync_credentials: syncCredentials
                })
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const result = await response.json();
            return { success: true, data: result };
        } catch (error) {
            console.error('Error triggering sync push:', error);
            throw error;
        }
    }

}

// Export the API instance
const api = new CompenSureAPI();